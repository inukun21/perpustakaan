<?php
session_start();
require_once 'config.php';
require_once 'check_role.php';

// Cek apakah user sudah login dan memiliki role admin
checkAdmin();

// Proses tambah peminjaman
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah_peminjaman'])) {
    $buku_id = mysqli_real_escape_string($conn, $_POST['buku_id']);
    $user_id = mysqli_real_escape_string($conn, $_POST['user_id']);
    $tanggal_pinjam = mysqli_real_escape_string($conn, $_POST['tanggal_pinjam']);
    
    // Cek stok buku
    $query_stok = "SELECT stok FROM buku WHERE id = $buku_id";
    $result_stok = mysqli_query($conn, $query_stok);
    $stok = mysqli_fetch_assoc($result_stok)['stok'];
    
    if ($stok > 0) {
        // Update stok buku
        mysqli_query($conn, "UPDATE buku SET stok = stok - 1 WHERE id = $buku_id");
        
        // Tambah peminjaman
        $query = "INSERT INTO peminjaman (buku_id, user_id, tanggal_pinjam) 
                  VALUES ($buku_id, $user_id, '$tanggal_pinjam')";
        mysqli_query($conn, $query);
    }
}

// Proses pengembalian buku
if (isset($_GET['kembalikan'])) {
    $peminjaman_id = mysqli_real_escape_string($conn, $_GET['kembalikan']);
    
    // Ambil buku_id dari peminjaman
    $query_buku = "SELECT buku_id FROM peminjaman WHERE id = $peminjaman_id";
    $result_buku = mysqli_query($conn, $query_buku);
    $buku_id = mysqli_fetch_assoc($result_buku)['buku_id'];
    
    // Update status peminjaman
    mysqli_query($conn, "UPDATE peminjaman SET status = 'dikembalikan', tanggal_kembali = CURRENT_DATE WHERE id = $peminjaman_id");
    
    // Kembalikan stok buku
    mysqli_query($conn, "UPDATE buku SET stok = stok + 1 WHERE id = $buku_id");
    
    header('Location: peminjaman.php');
    exit();
}

// Mengambil statistik peminjaman
$query_total = "SELECT COUNT(*) as total FROM peminjaman";
$query_aktif = "SELECT COUNT(*) as total FROM peminjaman WHERE status = 'dipinjam'";
$query_kembali = "SELECT COUNT(*) as total FROM peminjaman WHERE status = 'dikembalikan'";

$result_total = mysqli_query($conn, $query_total);
$result_aktif = mysqli_query($conn, $query_aktif);
$result_kembali = mysqli_query($conn, $query_kembali);

$total_peminjaman = mysqli_fetch_assoc($result_total)['total'];
$peminjaman_aktif = mysqli_fetch_assoc($result_aktif)['total'];
$peminjaman_kembali = mysqli_fetch_assoc($result_kembali)['total'];

// Mengambil data peminjaman
$query_peminjaman = "SELECT p.*, b.judul as judul_buku, u.nama_lengkap as nama_user 
                     FROM peminjaman p 
                     JOIN buku b ON p.buku_id = b.id 
                     JOIN users u ON p.user_id = u.id 
                     ORDER BY p.created_at DESC";
$result_peminjaman = mysqli_query($conn, $query_peminjaman);

// Mengambil data buku untuk dropdown
$query_buku = "SELECT * FROM buku WHERE stok > 0";
$result_buku = mysqli_query($conn, $query_buku);

// Mengambil data user untuk dropdown
$query_user = "SELECT * FROM users WHERE role = 'siswa'";
$result_user = mysqli_query($conn, $query_user);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Peminjaman - Perpustakaan Digital</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f6f9;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #fff;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            height: 70px;
        }
        .header h1 {
            font-size: 24px;
            font-weight: 500;
            margin: 0;
        }
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 16px;
        }
        .user-info i {
            font-size: 24px;
        }
        .sidebar {
            background-color: #fff;
            width: 250px;
            height: calc(100vh - 70px);
            position: fixed;
            left: 0;
            top: 70px;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px 0;
            transition: all 0.3s ease;
            z-index: 999;
        }
        .menu-item {
            padding: 15px 25px;
            display: flex;
            align-items: center;
            gap: 15px;
            color: #555;
            text-decoration: none;
            transition: all 0.3s ease;
            font-size: 15px;
            border-left: 4px solid transparent;
        }
        .menu-item:hover {
            background-color: #f8f9fa;
            color: #667eea;
        }
        .menu-item.active {
            background-color: #f0f2ff;
            color: #667eea;
            border-left: 4px solid #667eea;
        }
        .menu-item i {
            width: 20px;
            text-align: center;
            font-size: 18px;
        }
        .content {
            margin-left: 250px;
            padding: 90px 30px 30px;
            transition: all 0.3s ease;
            min-height: 100vh;
        }
        .peminjaman-section {
            background: #fff;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }
        .peminjaman-section h3 {
            color: #333;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        th {
            color: #666;
            font-weight: 500;
        }
        .action-button {
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s ease;
        }
        .kembalikan-button {
            background-color: #4CAF50;
            color: white;
        }
        .kembalikan-button:hover {
            background-color: #45a049;
        }
        .tambah-button {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 12px 25px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-size: 16px;
            margin-bottom: 20px;
            transition: all 0.3s ease;
        }
        .tambah-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 1001;
        }
        .modal-content {
            background-color: #fff;
            padding: 30px;
            border-radius: 15px;
            width: 90%;
            max-width: 500px;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #555;
        }
        .form-group select, .form-group input {
            width: 100%;
            padding: 10px;
            border: 2px solid #e1e1e1;
            border-radius: 5px;
            font-size: 14px;
        }
        .form-group select:focus, .form-group input:focus {
            border-color: #667eea;
            outline: none;
        }
        .close-button {
            position: absolute;
            top: 15px;
            right: 15px;
            font-size: 24px;
            cursor: pointer;
            color: #666;
        }
        .mobile-menu-button {
            display: none;
            font-size: 24px;
            cursor: pointer;
        }
        @media (max-width: 768px) {
            .mobile-menu-button {
                display: block;
            }
            .sidebar {
                transform: translateX(-100%);
            }
            .sidebar.active {
                transform: translateX(0);
            }
            .content {
                margin-left: 0;
            }
            table {
                display: block;
                overflow-x: auto;
            }
        }
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: #fff;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: #fff;
        }
        .stat-info h3 {
            color: #666;
            font-size: 14px;
            margin-bottom: 5px;
        }
        .stat-info p {
            color: #333;
            font-size: 24px;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="header">
        <div style="display: flex; align-items: center; gap: 15px;">
            <i class="fas fa-bars mobile-menu-button"></i>
            <h1>LIBDIG YOSAGI</h1>
        </div>
        <div class="user-info">
            <i class="fas fa-user-circle"></i>
            <span><?php echo htmlspecialchars($_SESSION['nama_lengkap']); ?></span>
        </div>
    </div>
    <div class="sidebar">
        <a href="index.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">
            <i class="fas fa-home"></i>
            <span>Beranda</span>
        </a>
        <a href="buku.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'buku.php' ? 'active' : ''; ?>">
            <i class="fas fa-book"></i>
            <span>Manajemen Buku</span>
        </a>
        <a href="buku_digital.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'buku_digital.php' ? 'active' : ''; ?>">
            <i class="fas fa-tablet-alt"></i>
            <span>Buku Digital</span>
        </a>
        <a href="peminjaman.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'peminjaman.php' ? 'active' : ''; ?>">
            <i class="fas fa-exchange-alt"></i>
            <span>Manajemen Peminjaman</span>
        </a>
        <a href="users.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'users.php' ? 'active' : ''; ?>">
            <i class="fas fa-users"></i>
            <span>Manajemen Pengguna</span>
        </a>
        <a href="laporan.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'laporan.php' ? 'active' : ''; ?>">
            <i class="fas fa-chart-bar"></i>
            <span>Laporan</span>
        </a>
        <a href="profil.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'profil.php' ? 'active' : ''; ?>">
            <i class="fas fa-user"></i>
            <span>Profil Saya</span>
        </a>
        <a href="logout.php" class="menu-item">
            <i class="fas fa-sign-out-alt"></i>
            <span>Keluar</span>
        </a>
    </div>
    <div class="content">
        <div class="stats-container">
            <div class="stat-card">
                <div class="stat-icon" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                    <i class="fas fa-book-reader"></i>
                </div>
                <div class="stat-info">
                    <h3>Total Peminjaman</h3>
                    <p><?php echo $total_peminjaman; ?></p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: linear-gradient(135deg, #ff6b6b 0%, #ee0979 100%);">
                    <i class="fas fa-clock"></i>
                </div>
                <div class="stat-info">
                    <h3>Peminjaman Aktif</h3>
                    <p><?php echo $peminjaman_aktif; ?></p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: linear-gradient(135deg, #00b09b 0%, #96c93d 100%);">
                    <i class="fas fa-check-circle"></i>
                </div>
                <div class="stat-info">
                    <h3>Buku Dikembalikan</h3>
                    <p><?php echo $peminjaman_kembali; ?></p>
                </div>
            </div>
        </div>
        <div class="peminjaman-section">
            <h3>Daftar Peminjaman</h3>
            <button class="tambah-button" onclick="openModal()">
                <i class="fas fa-plus"></i> Tambah Peminjaman
            </button>
            <table>
                <thead>
                    <tr>
                        <th>Buku</th>
                        <th>Peminjam</th>
                        <th>Tanggal Pinjam</th>
                        <th>Tanggal Kembali</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($peminjaman = mysqli_fetch_assoc($result_peminjaman)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($peminjaman['judul_buku']); ?></td>
                        <td><?php echo htmlspecialchars($peminjaman['nama_user']); ?></td>
                        <td><?php echo date('d/m/Y', strtotime($peminjaman['tanggal_pinjam'])); ?></td>
                        <td><?php echo $peminjaman['tanggal_kembali'] ? date('d/m/Y', strtotime($peminjaman['tanggal_kembali'])) : '-'; ?></td>
                        <td><?php echo ucfirst($peminjaman['status']); ?></td>
                        <td>
                            <?php if ($peminjaman['status'] === 'dipinjam'): ?>
                            <button class="action-button kembalikan-button" 
                                    onclick="if(confirm('Apakah Anda yakin ingin mengembalikan buku ini?')) 
                                            window.location.href='peminjaman.php?kembalikan=<?php echo $peminjaman['id']; ?>'">
                                <i class="fas fa-undo"></i> Kembalikan
                            </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Modal Tambah Peminjaman -->
    <div id="tambahModal" class="modal">
        <div class="modal-content">
            <span class="close-button" onclick="closeModal()">&times;</span>
            <h3 style="margin-bottom: 20px;">Tambah Peminjaman</h3>
            <form action="peminjaman.php" method="POST">
                <div class="form-group">
                    <label for="buku_id">Buku</label>
                    <select name="buku_id" id="buku_id" required>
                        <option value="">Pilih Buku</option>
                        <?php while ($buku = mysqli_fetch_assoc($result_buku)): ?>
                        <option value="<?php echo $buku['id']; ?>">
                            <?php echo htmlspecialchars($buku['judul']); ?> (Stok: <?php echo $buku['stok']; ?>)
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="user_id">Peminjam</label>
                    <select name="user_id" id="user_id" required>
                        <option value="">Pilih Peminjam</option>
                        <?php while ($user = mysqli_fetch_assoc($result_user)): ?>
                        <option value="<?php echo $user['id']; ?>">
                            <?php echo htmlspecialchars($user['nama_lengkap']); ?> (<?php echo $user['nisn']; ?>)
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="tanggal_pinjam">Tanggal Pinjam</label>
                    <input type="date" name="tanggal_pinjam" id="tanggal_pinjam" required>
                </div>
                <button type="submit" name="tambah_peminjaman" class="tambah-button">
                    <i class="fas fa-plus"></i> Tambah Peminjaman
                </button>
            </form>
        </div>
    </div>

    <script>
        // Mobile menu toggle
        const mobileMenuButton = document.querySelector('.mobile-menu-button');
        const sidebar = document.querySelector('.sidebar');
        
        mobileMenuButton.addEventListener('click', () => {
            sidebar.classList.toggle('active');
        });

        // Close sidebar when clicking outside
        document.addEventListener('click', (e) => {
            if (!sidebar.contains(e.target) && !mobileMenuButton.contains(e.target)) {
                sidebar.classList.remove('active');
            }
        });

        // Modal functions
        function openModal() {
            document.getElementById('tambahModal').style.display = 'block';
        }

        function closeModal() {
            document.getElementById('tambahModal').style.display = 'none';
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('tambahModal');
            if (event.target == modal) {
                modal.style.display = 'none';
            }
        }
    </script>
</body>
</html> 