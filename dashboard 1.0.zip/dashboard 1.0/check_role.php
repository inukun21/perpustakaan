<?php
function checkAdmin() {
    if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
        header('Location: unauthorized.php');
        exit();
    }
}

function checkGuru() {
    if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'guru') {
        header('Location: unauthorized.php');
        exit();
    }
}

function checkSiswa() {
    if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'siswa') {
        header('Location: unauthorized.php');
        exit();
    }
}
?> 