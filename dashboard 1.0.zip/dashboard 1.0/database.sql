CREATE DATABASE IF NOT EXISTS perpustakaan;
USE perpustakaan;

CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nama_lengkap VARCHAR(100) NOT NULL,
    nisn VARCHAR(20) NOT NULL UNIQUE,
    role ENUM('admin', 'guru', 'siswa') NOT NULL DEFAULT 'siswa',
    alamat TEXT,
    no_telp VARCHAR(15),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS buku (
    id INT PRIMARY KEY AUTO_INCREMENT,
    judul VARCHAR(255) NOT NULL,
    penulis VARCHAR(100) NOT NULL,
    isbn VARCHAR(20) NOT NULL UNIQUE,
    kategori VARCHAR(50) NOT NULL,
    stok INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS peminjaman (
    id INT PRIMARY KEY AUTO_INCREMENT,
    buku_id INT NOT NULL,
    user_id INT NOT NULL,
    tanggal_pinjam DATE NOT NULL,
    tanggal_kembali DATE,
    status ENUM('dipinjam', 'dikembalikan') NOT NULL DEFAULT 'dipinjam',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (buku_id) REFERENCES buku(id),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

INSERT INTO users (nama_lengkap, nisn, role, alamat, no_telp) VALUES 
('Admin Perpustakaan', '1234567890', 'admin', 'Jl. Admin No. 1', '081234567890'),
('Guru Matematika', '9876543210', 'guru', 'Jl. Guru No. 1', '081234567891'),
('Guru Bahasa Indonesia', '9876543211', 'guru', 'Jl. Guru No. 2', '081234567892'),
('Ahmad Fauzi', '2021001', 'siswa', 'Jl. Merdeka No. 1', '081234567893'),
('Budi Santoso', '2021002', 'siswa', 'Jl. Sudirman No. 2', '081234567894');

INSERT INTO buku (judul, penulis, isbn, kategori, stok) VALUES 
('Harry Potter dan Batu Bertuah', 'J.K. Rowling', '978-0-7475-3269-9', 'Fiksi', 5),
('Laskar Pelangi', 'Andrea Hirata', '978-979-3062-79-7', 'Fiksi', 3),
('Sejarah Indonesia Modern', 'M.C. Ricklefs', '978-979-3782-45-7', 'Sejarah', 2),
('Filosofi Teras', 'Henry Manampiring', '978-602-412-518-9', 'Non-Fiksi', 4),
('Biografi Steve Jobs', 'Walter Isaacson', '978-1-4516-4853-9', 'Biografi', 1);

INSERT INTO peminjaman (buku_id, user_id, tanggal_pinjam, status) VALUES 
(1, 4, '2024-03-01', 'dipinjam'),
(2, 5, '2024-03-02', 'dipinjam'),
(3, 4, '2024-03-03', 'dikembalikan'),
(4, 5, '2024-03-04', 'dipinjam'),
(5, 4, '2024-03-05', 'dikembalikan'); 