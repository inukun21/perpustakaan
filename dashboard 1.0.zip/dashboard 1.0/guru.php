<?php
session_start();
require_once 'config.php';
require_once 'check_role.php';

// Cek apakah user sudah login dan memiliki role guru
checkGuru();

// Mengambil data peminjaman
$query_peminjaman = "SELECT p.*, b.judul as judul_buku, u.nama_lengkap as nama_user 
                     FROM peminjaman p 
                     JOIN buku b ON p.buku_id = b.id 
                     JOIN users u ON p.user_id = u.id 
                     ORDER BY p.created_at DESC";
$result_peminjaman = mysqli_query($conn, $query_peminjaman);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Guru - Perpustakaan Digital</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f6f9;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #fff;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }
        .header h1 {
            font-size: 24px;
            font-weight: 500;
        }
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .user-info i {
            font-size: 20px;
        }
        .sidebar {
            background-color: #fff;
            width: 250px;
            height: calc(100vh - 70px);
            position: fixed;
            left: 0;
            top: 70px;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px 0;
            transition: all 0.3s ease;
        }
        .menu-item {
            padding: 15px 25px;
            display: flex;
            align-items: center;
            gap: 10px;
            color: #555;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        .menu-item:hover {
            background-color: #f8f9fa;
            color: #667eea;
        }
        .menu-item.active {
            background-color: #f0f2ff;
            color: #667eea;
            border-left: 4px solid #667eea;
        }
        .menu-item i {
            width: 20px;
            text-align: center;
        }
        .content {
            margin-left: 250px;
            padding: 90px 30px 30px;
            transition: all 0.3s ease;
        }
        .welcome-section {
            background: #fff;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            margin-bottom: 30px;
        }
        .welcome-section h2 {
            color: #333;
            margin-bottom: 10px;
        }
        .welcome-section p {
            color: #666;
        }
        .peminjaman-section {
            background: #fff;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }
        .peminjaman-section h3 {
            color: #333;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        th {
            color: #666;
            font-weight: 500;
        }
        .mobile-menu-button {
            display: none;
            font-size: 24px;
            cursor: pointer;
        }
        @media (max-width: 768px) {
            .mobile-menu-button {
                display: block;
            }
            .sidebar {
                transform: translateX(-100%);
            }
            .sidebar.active {
                transform: translateX(0);
            }
            .content {
                margin-left: 0;
            }
            table {
                display: block;
                overflow-x: auto;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <div style="display: flex; align-items: center; gap: 15px;">
            <i class="fas fa-bars mobile-menu-button"></i>
            <h1>Perpustakaan Digital</h1>
        </div>
        <div class="user-info">
            <i class="fas fa-user-circle"></i>
            <span><?php echo htmlspecialchars($_SESSION['nama_lengkap']); ?></span>
        </div>
    </div>
    <div class="sidebar">
        <a href="guru.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'guru.php' ? 'active' : ''; ?>">
            <i class="fas fa-home"></i>
            <span>Beranda</span>
        </a>
        <a href="daftar_buku.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'daftar_buku.php' ? 'active' : ''; ?>">
            <i class="fas fa-book"></i>
            <span>Daftar Buku</span>
        </a>
        <a href="daftar_peminjaman.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'daftar_peminjaman.php' ? 'active' : ''; ?>">
            <i class="fas fa-list"></i>
            <span>Daftar Peminjaman</span>
        </a>
        <a href="profil.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'profil.php' ? 'active' : ''; ?>">
            <i class="fas fa-user"></i>
            <span>Profil Saya</span>
        </a>
        <a href="logout.php" class="menu-item">
            <i class="fas fa-sign-out-alt"></i>
            <span>Keluar</span>
        </a>
    </div>
    <div class="content">
        <div class="welcome-section">
            <h2>Selamat Datang, <?php echo htmlspecialchars($_SESSION['nama_lengkap']); ?></h2>
            <p>Selamat datang di halaman dashboard guru perpustakaan digital.</p>
        </div>
        <div class="peminjaman-section">
            <h3>Daftar Peminjaman Terbaru</h3>
            <table>
                <thead>
                    <tr>
                        <th>Buku</th>
                        <th>Peminjam</th>
                        <th>Tanggal Pinjam</th>
                        <th>Tanggal Kembali</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($peminjaman = mysqli_fetch_assoc($result_peminjaman)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($peminjaman['judul_buku']); ?></td>
                        <td><?php echo htmlspecialchars($peminjaman['nama_user']); ?></td>
                        <td><?php echo date('d/m/Y', strtotime($peminjaman['tanggal_pinjam'])); ?></td>
                        <td><?php echo $peminjaman['tanggal_kembali'] ? date('d/m/Y', strtotime($peminjaman['tanggal_kembali'])) : '-'; ?></td>
                        <td><?php echo ucfirst($peminjaman['status']); ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        // Mobile menu toggle
        const mobileMenuButton = document.querySelector('.mobile-menu-button');
        const sidebar = document.querySelector('.sidebar');
        
        mobileMenuButton.addEventListener('click', () => {
            sidebar.classList.toggle('active');
        });

        // Close sidebar when clicking outside
        document.addEventListener('click', (e) => {
            if (!sidebar.contains(e.target) && !mobileMenuButton.contains(e.target)) {
                sidebar.classList.remove('active');
            }
        });
    </script>
</body>
</html> 