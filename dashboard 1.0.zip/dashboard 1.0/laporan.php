<?php
session_start();
require_once 'config.php';
require_once 'check_role.php';

// Cek apakah user sudah login dan memiliki role admin
checkAdmin();

// Filter tanggal
$tanggal_mulai = isset($_GET['tanggal_mulai']) ? $_GET['tanggal_mulai'] : date('Y-m-01');
$tanggal_akhir = isset($_GET['tanggal_akhir']) ? $_GET['tanggal_akhir'] : date('Y-m-t');

// Statistik peminjaman
$query_total_peminjaman = "SELECT COUNT(*) as total FROM peminjaman 
                          WHERE tanggal_pinjam BETWEEN '$tanggal_mulai' AND '$tanggal_akhir'";
$query_peminjaman_aktif = "SELECT COUNT(*) as total FROM peminjaman 
                          WHERE status = 'dipinjam' AND tanggal_pinjam BETWEEN '$tanggal_mulai' AND '$tanggal_akhir'";
$query_peminjaman_kembali = "SELECT COUNT(*) as total FROM peminjaman 
                            WHERE status = 'dikembalikan' AND tanggal_pinjam BETWEEN '$tanggal_mulai' AND '$tanggal_akhir'";

$result_total_peminjaman = mysqli_query($conn, $query_total_peminjaman);
$result_peminjaman_aktif = mysqli_query($conn, $query_peminjaman_aktif);
$result_peminjaman_kembali = mysqli_query($conn, $query_peminjaman_kembali);

$total_peminjaman = mysqli_fetch_assoc($result_total_peminjaman)['total'];
$peminjaman_aktif = mysqli_fetch_assoc($result_peminjaman_aktif)['total'];
$peminjaman_kembali = mysqli_fetch_assoc($result_peminjaman_kembali)['total'];

// Data peminjaman detail
$query_peminjaman = "SELECT p.*, b.judul as judul_buku, u.nama_lengkap as nama_user, u.role as role_user
                     FROM peminjaman p 
                     JOIN buku b ON p.buku_id = b.id 
                     JOIN users u ON p.user_id = u.id 
                     WHERE p.tanggal_pinjam BETWEEN '$tanggal_mulai' AND '$tanggal_akhir'
                     ORDER BY p.tanggal_pinjam DESC";
$result_peminjaman = mysqli_query($conn, $query_peminjaman);

// Buku terpopuler
$query_buku_populer = "SELECT b.judul, COUNT(p.id) as total_peminjaman 
                       FROM buku b 
                       LEFT JOIN peminjaman p ON b.id = p.buku_id 
                       WHERE p.tanggal_pinjam BETWEEN '$tanggal_mulai' AND '$tanggal_akhir'
                       GROUP BY b.id 
                       ORDER BY total_peminjaman DESC 
                       LIMIT 5";
$result_buku_populer = mysqli_query($conn, $query_buku_populer);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan - Perpustakaan Digital</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f6f9;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #fff;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            height: 70px;
        }
        .header h1 {
            font-size: 24px;
            font-weight: 500;
            margin: 0;
        }
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 16px;
        }
        .user-info i {
            font-size: 24px;
        }
        .sidebar {
            background-color: #fff;
            width: 250px;
            height: calc(100vh - 70px);
            position: fixed;
            left: 0;
            top: 70px;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px 0;
            transition: all 0.3s ease;
            z-index: 999;
        }
        .menu-item {
            padding: 15px 25px;
            display: flex;
            align-items: center;
            gap: 15px;
            color: #555;
            text-decoration: none;
            transition: all 0.3s ease;
            font-size: 15px;
            border-left: 4px solid transparent;
        }
        .menu-item:hover {
            background-color: #f8f9fa;
            color: #667eea;
        }
        .menu-item.active {
            background-color: #f0f2ff;
            color: #667eea;
            border-left: 4px solid #667eea;
        }
        .menu-item i {
            width: 20px;
            text-align: center;
            font-size: 18px;
        }
        .content {
            margin-left: 250px;
            padding: 90px 30px 30px;
            transition: all 0.3s ease;
            min-height: 100vh;
        }
        .section {
            background: #fff;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            margin-bottom: 30px;
        }
        .section h3 {
            color: #333;
            margin-bottom: 20px;
        }
        .filter-form {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
        }
        .filter-form input[type="date"] {
            padding: 8px 12px;
            border: 2px solid #e1e1e1;
            border-radius: 5px;
            font-size: 14px;
        }
        .filter-button {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 8px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s ease;
        }
        .filter-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: #fff;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: #fff;
        }
        .stat-info h3 {
            color: #666;
            font-size: 14px;
            margin-bottom: 5px;
        }
        .stat-info p {
            color: #333;
            font-size: 24px;
            font-weight: 600;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        th {
            color: #666;
            font-weight: 500;
        }
        .status-badge {
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 12px;
            font-weight: 500;
        }
        .status-dipinjam {
            background-color: #fff3cd;
            color: #856404;
        }
        .status-dikembalikan {
            background-color: #d4edda;
            color: #155724;
        }
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            .sidebar.active {
                transform: translateX(0);
            }
            .content {
                margin-left: 0;
            }
            table {
                display: block;
                overflow-x: auto;
            }
            .filter-form {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <div style="display: flex; align-items: center; gap: 15px;">
            <i class="fas fa-bars mobile-menu-button"></i>
            <h1>LIBDIG YOSAGI</h1>
        </div>
        <div class="user-info">
            <i class="fas fa-user-circle"></i>
            <span><?php echo htmlspecialchars($_SESSION['nama_lengkap']); ?></span>
        </div>
    </div>
    <div class="sidebar">
        <a href="index.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">
            <i class="fas fa-home"></i>
            <span>Beranda</span>
        </a>
        <a href="buku.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'buku.php' ? 'active' : ''; ?>">
            <i class="fas fa-book"></i>
            <span>Manajemen Buku</span>
        </a>
        <a href="buku_digital.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'buku_digital.php' ? 'active' : ''; ?>">
            <i class="fas fa-tablet-alt"></i>
            <span>Buku Digital</span>
        </a>
        <a href="peminjaman.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'peminjaman.php' ? 'active' : ''; ?>">
            <i class="fas fa-exchange-alt"></i>
            <span>Manajemen Peminjaman</span>
        </a>
        <a href="users.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'users.php' ? 'active' : ''; ?>">
            <i class="fas fa-users"></i>
            <span>Manajemen Pengguna</span>
        </a>
        <a href="laporan.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'laporan.php' ? 'active' : ''; ?>">
            <i class="fas fa-chart-bar"></i>
            <span>Laporan</span>
        </a>
        <a href="profil.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'profil.php' ? 'active' : ''; ?>">
            <i class="fas fa-user"></i>
            <span>Profil Saya</span>
        </a>
        <a href="logout.php" class="menu-item">
            <i class="fas fa-sign-out-alt"></i>
            <span>Keluar</span>
        </a>
    </div>
    <div class="content">
        <div class="section">
            <h3>Laporan Peminjaman</h3>
            <form class="filter-form" method="GET">
                <input type="date" name="tanggal_mulai" value="<?php echo $tanggal_mulai; ?>" required>
                <input type="date" name="tanggal_akhir" value="<?php echo $tanggal_akhir; ?>" required>
                <button type="submit" class="filter-button">
                    <i class="fas fa-filter"></i> Filter
                </button>
            </form>
            <div class="stats-container">
                <div class="stat-card">
                    <div class="stat-icon" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                        <i class="fas fa-book-reader"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Total Peminjaman</h3>
                        <p><?php echo $total_peminjaman; ?></p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon" style="background: linear-gradient(135deg, #ff6b6b 0%, #ee0979 100%);">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Peminjaman Aktif</h3>
                        <p><?php echo $peminjaman_aktif; ?></p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon" style="background: linear-gradient(135deg, #00b09b 0%, #96c93d 100%);">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Buku Dikembalikan</h3>
                        <p><?php echo $peminjaman_kembali; ?></p>
                    </div>
                </div>
            </div>
            <h3>Buku Terpopuler</h3>
            <table style="margin-bottom: 30px;">
                <thead>
                    <tr>
                        <th>Judul Buku</th>
                        <th>Total Peminjaman</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($buku = mysqli_fetch_assoc($result_buku_populer)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($buku['judul']); ?></td>
                        <td><?php echo $buku['total_peminjaman']; ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
            <h3>Detail Peminjaman</h3>
            <table>
                <thead>
                    <tr>
                        <th>Tanggal Pinjam</th>
                        <th>Judul Buku</th>
                        <th>Peminjam</th>
                        <th>Role</th>
                        <th>Tanggal Kembali</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($peminjaman = mysqli_fetch_assoc($result_peminjaman)): ?>
                    <tr>
                        <td><?php echo date('d/m/Y', strtotime($peminjaman['tanggal_pinjam'])); ?></td>
                        <td><?php echo htmlspecialchars($peminjaman['judul_buku']); ?></td>
                        <td><?php echo htmlspecialchars($peminjaman['nama_user']); ?></td>
                        <td><?php echo ucfirst($peminjaman['role_user']); ?></td>
                        <td><?php echo $peminjaman['tanggal_kembali'] ? date('d/m/Y', strtotime($peminjaman['tanggal_kembali'])) : '-'; ?></td>
                        <td>
                            <span class="status-badge status-<?php echo $peminjaman['status']; ?>">
                                <?php echo ucfirst($peminjaman['status']); ?>
                            </span>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        // Mobile menu toggle
        const mobileMenuButton = document.querySelector('.mobile-menu-button');
        const sidebar = document.querySelector('.sidebar');
        
        mobileMenuButton.addEventListener('click', () => {
            sidebar.classList.toggle('active');
        });

        // Close sidebar when clicking outside
        document.addEventListener('click', (e) => {
            if (!sidebar.contains(e.target) && !mobileMenuButton.contains(e.target)) {
                sidebar.classList.remove('active');
            }
        });
    </script>
</body>
</html> 