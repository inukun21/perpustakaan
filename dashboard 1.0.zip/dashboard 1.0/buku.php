<?php
session_start();
require_once 'config.php';
require_once 'check_role.php';

// Cek apakah user sudah login dan memiliki role admin
checkAdmin();

// Proses tambah buku
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah_buku'])) {
    $judul = mysqli_real_escape_string($conn, $_POST['judul']);
    $penulis = mysqli_real_escape_string($conn, $_POST['penulis']);
    $isbn = mysqli_real_escape_string($conn, $_POST['isbn']);
    $kategori = mysqli_real_escape_string($conn, $_POST['kategori']);
    $stok = mysqli_real_escape_string($conn, $_POST['stok']);
    
    $query = "INSERT INTO buku (judul, penulis, isbn, kategori, stok) 
              VALUES ('$judul', '$penulis', '$isbn', '$kategori', '$stok')";
    mysqli_query($conn, $query);
    
    header('Location: buku.php');
    exit();
}

// Proses hapus buku
if (isset($_GET['hapus'])) {
    $id = mysqli_real_escape_string($conn, $_GET['hapus']);
    
    // Cek apakah buku masih dipinjam
    $query_check = "SELECT COUNT(*) as total FROM peminjaman WHERE buku_id = $id AND status = 'dipinjam'";
    $result_check = mysqli_query($conn, $query_check);
    $count = mysqli_fetch_assoc($result_check)['total'];
    
    if ($count > 0) {
        echo "<script>alert('Buku tidak dapat dihapus karena masih dalam peminjaman!'); window.location.href='buku.php';</script>";
        exit();
    } else {
        // Hapus data peminjaman yang sudah dikembalikan terlebih dahulu
        mysqli_query($conn, "DELETE FROM peminjaman WHERE buku_id = $id AND status = 'dikembalikan'");
        // Kemudian hapus buku
        mysqli_query($conn, "DELETE FROM buku WHERE id = $id");
        header('Location: buku.php');
        exit();
    }
}

// Mengambil data buku
$query_buku = "SELECT * FROM buku ORDER BY created_at DESC";
$result_buku = mysqli_query($conn, $query_buku);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Buku - Perpustakaan Digital</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f6f9;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #fff;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }
        .header h1 {
            font-size: 24px;
            font-weight: 500;
        }
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .user-info i {
            font-size: 20px;
        }
        .sidebar {
            background-color: #fff;
            width: 250px;
            height: calc(100vh - 70px);
            position: fixed;
            left: 0;
            top: 70px;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px 0;
            transition: all 0.3s ease;
        }
        .menu-item {
            padding: 15px 25px;
            display: flex;
            align-items: center;
            gap: 10px;
            color: #555;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        .menu-item:hover {
            background-color: #f8f9fa;
            color: #667eea;
        }
        .menu-item.active {
            background-color: #f0f2ff;
            color: #667eea;
            border-left: 4px solid #667eea;
        }
        .menu-item i {
            width: 20px;
            text-align: center;
        }
        .content {
            margin-left: 250px;
            padding: 90px 30px 30px;
            transition: all 0.3s ease;
            min-height: 100vh;
        }
        .section {
            background: #fff;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            margin-bottom: 30px;
        }
        .section h3 {
            color: #333;
            margin-bottom: 20px;
            font-size: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        th {
            color: #666;
            font-weight: 500;
            font-size: 14px;
        }
        td {
            font-size: 14px;
        }
        .tambah-button {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 12px 25px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-size: 16px;
            margin-bottom: 20px;
            transition: all 0.3s ease;
        }
        .tambah-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        .action-button {
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s ease;
            margin-right: 5px;
        }
        .edit-button {
            background-color: #ffc107;
            color: white;
        }
        .hapus-button {
            background-color: #dc3545;
            color: white;
        }
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 1001;
        }
        .modal-content {
            background-color: #fff;
            padding: 30px;
            border-radius: 15px;
            width: 90%;
            max-width: 500px;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #555;
            font-size: 14px;
        }
        .form-group input, .form-group select {
            width: 100%;
            padding: 10px;
            border: 2px solid #e1e1e1;
            border-radius: 5px;
            font-size: 14px;
        }
        .form-group input:focus, .form-group select:focus {
            border-color: #667eea;
            outline: none;
        }
        .close-button {
            position: absolute;
            top: 15px;
            right: 15px;
            font-size: 24px;
            cursor: pointer;
            color: #666;
        }
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            .sidebar.active {
                transform: translateX(0);
            }
            .content {
                margin-left: 0;
                padding: 80px 15px 15px;
            }
            table {
                display: block;
                overflow-x: auto;
            }
            .section {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <div style="display: flex; align-items: center; gap: 15px;">
            <i class="fas fa-bars mobile-menu-button"></i>
            <h1>LIBDIG YOSAGI</h1>
        </div>
        <div class="user-info">
            <i class="fas fa-user-circle"></i>
            <span><?php echo htmlspecialchars($_SESSION['nama_lengkap']); ?></span>
        </div>
    </div>
    <div class="sidebar">
        <a href="index.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">
            <i class="fas fa-home"></i>
            <span>Beranda</span>
        </a>
        <a href="buku.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'buku.php' ? 'active' : ''; ?>">
            <i class="fas fa-book"></i>
            <span>Manajemen Buku</span>
        </a>
        <a href="buku_digital.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'buku_digital.php' ? 'active' : ''; ?>">
            <i class="fas fa-tablet-alt"></i>
            <span>Buku Digital</span>
        </a>
        <a href="peminjaman.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'peminjaman.php' ? 'active' : ''; ?>">
            <i class="fas fa-exchange-alt"></i>
            <span>Manajemen Peminjaman</span>
        </a>
        <a href="users.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'users.php' ? 'active' : ''; ?>">
            <i class="fas fa-users"></i>
            <span>Manajemen Pengguna</span>
        </a>
        <a href="laporan.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'laporan.php' ? 'active' : ''; ?>">
            <i class="fas fa-chart-bar"></i>
            <span>Laporan</span>
        </a>
        <a href="profil.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'profil.php' ? 'active' : ''; ?>">
            <i class="fas fa-user"></i>
            <span>Profil Saya</span>
        </a>
        <a href="logout.php" class="menu-item">
            <i class="fas fa-sign-out-alt"></i>
            <span>Keluar</span>
        </a>
    </div>
    <div class="content">
        <div class="section">
            <h3>Manajemen Buku</h3>
            <button class="tambah-button" onclick="openModal()">
                <i class="fas fa-plus"></i> Tambah Buku
            </button>
            <table>
                <thead>
                    <tr>
                        <th>Judul</th>
                        <th>Penulis</th>
                        <th>ISBN</th>
                        <th>Kategori</th>
                        <th>Stok</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($buku = mysqli_fetch_assoc($result_buku)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($buku['judul']); ?></td>
                        <td><?php echo htmlspecialchars($buku['penulis']); ?></td>
                        <td><?php echo htmlspecialchars($buku['isbn']); ?></td>
                        <td><?php echo htmlspecialchars($buku['kategori']); ?></td>
                        <td><?php echo $buku['stok']; ?></td>
                        <td>
                            <button class="action-button edit-button" onclick="editBuku(<?php echo $buku['id']; ?>)">
                                <i class="fas fa-edit"></i> Edit
                            </button>
                            <button class="action-button hapus-button" 
                                    onclick="if(confirm('Apakah Anda yakin ingin menghapus buku ini?')) 
                                            window.location.href='buku.php?hapus=<?php echo $buku['id']; ?>'">
                                <i class="fas fa-trash"></i> Hapus
                            </button>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Modal Tambah Buku -->
    <div id="tambahModal" class="modal">
        <div class="modal-content">
            <span class="close-button" onclick="closeModal()">&times;</span>
            <h3 style="margin-bottom: 20px;">Tambah Buku</h3>
            <form action="buku.php" method="POST">
                <div class="form-group">
                    <label for="judul">Judul Buku</label>
                    <input type="text" id="judul" name="judul" required>
                </div>
                <div class="form-group">
                    <label for="penulis">Penulis</label>
                    <input type="text" id="penulis" name="penulis" required>
                </div>
                <div class="form-group">
                    <label for="isbn">ISBN</label>
                    <input type="text" id="isbn" name="isbn" required>
                </div>
                <div class="form-group">
                    <label for="kategori">Kategori</label>
                    <input type="text" id="kategori" name="kategori" required>
                </div>
                <div class="form-group">
                    <label for="stok">Stok</label>
                    <input type="number" id="stok" name="stok" min="0" required>
                </div>
                <button type="submit" name="tambah_buku" class="tambah-button">
                    <i class="fas fa-plus"></i> Tambah Buku
                </button>
            </form>
        </div>
    </div>

    <script>
        // Mobile menu toggle
        const mobileMenuButton = document.querySelector('.mobile-menu-button');
        const sidebar = document.querySelector('.sidebar');
        
        mobileMenuButton.addEventListener('click', () => {
            sidebar.classList.toggle('active');
        });

        // Close sidebar when clicking outside
        document.addEventListener('click', (e) => {
            if (!sidebar.contains(e.target) && !mobileMenuButton.contains(e.target)) {
                sidebar.classList.remove('active');
            }
        });

        // Modal functions
        function openModal() {
            document.getElementById('tambahModal').style.display = 'block';
        }

        function closeModal() {
            document.getElementById('tambahModal').style.display = 'none';
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('tambahModal');
            if (event.target == modal) {
                modal.style.display = 'none';
            }
        }

        function editBuku(id) {
            // Implementasi fungsi edit buku akan segera hadir!
            alert('Fitur edit buku akan segera hadir!');
        }
    </script>
</body>
</html> 