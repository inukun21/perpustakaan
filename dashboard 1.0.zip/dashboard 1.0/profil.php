<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Mengambil data user
$query = "SELECT * FROM users WHERE id = $user_id";
$result = mysqli_query($conn, $query);
$user = mysqli_fetch_assoc($result);

// Proses update profil
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profil'])) {
    $nama_lengkap = mysqli_real_escape_string($conn, $_POST['nama_lengkap']);
    $alamat = mysqli_real_escape_string($conn, $_POST['alamat']);
    $no_telp = mysqli_real_escape_string($conn, $_POST['no_telp']);
    
    $query = "UPDATE users SET 
              nama_lengkap = '$nama_lengkap',
              alamat = '$alamat',
              no_telp = '$no_telp'
              WHERE id = $user_id";
    
    if (mysqli_query($conn, $query)) {
        $_SESSION['nama_lengkap'] = $nama_lengkap;
        $success = "Profil berhasil diperbarui!";
        
        // Refresh data user
        $result = mysqli_query($conn, "SELECT * FROM users WHERE id = $user_id");
        $user = mysqli_fetch_assoc($result);
    } else {
        $error = "Gagal memperbarui profil!";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Saya - Perpustakaan Digital</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f6f9;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #fff;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            height: 70px;
        }
        .header h1 {
            font-size: 24px;
            font-weight: 500;
            margin: 0;
        }
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 16px;
        }
        .user-info i {
            font-size: 24px;
        }
        .sidebar {
            background-color: #fff;
            width: 250px;
            height: calc(100vh - 70px);
            position: fixed;
            left: 0;
            top: 70px;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px 0;
            transition: all 0.3s ease;
            z-index: 999;
        }
        .menu-item {
            padding: 15px 25px;
            display: flex;
            align-items: center;
            gap: 15px;
            color: #555;
            text-decoration: none;
            transition: all 0.3s ease;
            font-size: 15px;
            border-left: 4px solid transparent;
        }
        .menu-item:hover {
            background-color: #f8f9fa;
            color: #667eea;
        }
        .menu-item.active {
            background-color: #f0f2ff;
            color: #667eea;
            border-left: 4px solid #667eea;
        }
        .menu-item i {
            width: 20px;
            text-align: center;
            font-size: 18px;
        }
        .content {
            margin-left: 250px;
            padding: 90px 30px 30px;
            transition: all 0.3s ease;
            min-height: 100vh;
        }
        .section {
            background: #fff;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            margin-bottom: 30px;
            max-width: 800px;
            margin: 0 auto;
        }
        .section h3 {
            color: #333;
            margin-bottom: 20px;
        }
        .profile-header {
            text-align: center;
            margin-bottom: 30px;
        }
        .profile-avatar {
            width: 120px;
            height: 120px;
            border-radius: 60px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 48px;
            margin: 0 auto 15px;
        }
        .profile-role {
            display: inline-block;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 500;
            margin-top: 10px;
        }
        .role-admin {
            background-color: #e3f2fd;
            color: #1976d2;
        }
        .role-guru {
            background-color: #f3e5f5;
            color: #7b1fa2;
        }
        .role-siswa {
            background-color: #e8f5e9;
            color: #388e3c;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #555;
            font-weight: 500;
        }
        .form-group input {
            width: 100%;
            padding: 10px;
            border: 2px solid #e1e1e1;
            border-radius: 5px;
            font-size: 14px;
            transition: all 0.3s ease;
        }
        .form-group input:focus {
            border-color: #667eea;
            outline: none;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        .form-group input[readonly] {
            background-color: #f8f9fa;
            cursor: not-allowed;
        }
        .update-button {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 12px 25px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
            transition: all 0.3s ease;
        }
        .update-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        .alert {
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-size: 14px;
        }
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            .sidebar.active {
                transform: translateX(0);
            }
            .content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <div style="display: flex; align-items: center; gap: 15px;">
            <i class="fas fa-bars mobile-menu-button"></i>
            <h1>LIBDIG YOSAGI</h1>
        </div>
        <div class="user-info">
            <i class="fas fa-user-circle"></i>
            <span><?php echo htmlspecialchars($_SESSION['nama_lengkap']); ?></span>
        </div>
    </div>
    <div class="sidebar">
        <?php if ($_SESSION['role'] === 'admin'): ?>
        <a href="index.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">
            <i class="fas fa-home"></i>
            <span>Beranda</span>
        </a>
        <a href="buku.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'buku.php' ? 'active' : ''; ?>">
            <i class="fas fa-book"></i>
            <span>Manajemen Buku</span>
        </a>
        <a href="buku_digital.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'buku_digital.php' ? 'active' : ''; ?>">
            <i class="fas fa-tablet-alt"></i>
            <span>Buku Digital</span>
        </a>
        <a href="peminjaman.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'peminjaman.php' ? 'active' : ''; ?>">
            <i class="fas fa-exchange-alt"></i>
            <span>Manajemen Peminjaman</span>
        </a>
        <a href="users.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'users.php' ? 'active' : ''; ?>">
            <i class="fas fa-users"></i>
            <span>Manajemen Pengguna</span>
        </a>
        <a href="laporan.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'laporan.php' ? 'active' : ''; ?>">
            <i class="fas fa-chart-bar"></i>
            <span>Laporan</span>
        </a>
        <?php elseif ($_SESSION['role'] === 'guru'): ?>
        <a href="guru.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'guru.php' ? 'active' : ''; ?>">
            <i class="fas fa-home"></i>
            <span>Beranda</span>
        </a>
        <a href="daftar_buku.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'daftar_buku.php' ? 'active' : ''; ?>">
            <i class="fas fa-book"></i>
            <span>Daftar Buku</span>
        </a>
        <a href="daftar_peminjaman.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'daftar_peminjaman.php' ? 'active' : ''; ?>">
            <i class="fas fa-list"></i>
            <span>Daftar Peminjaman</span>
        </a>
        <?php else: ?>
        <a href="siswa.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'siswa.php' ? 'active' : ''; ?>">
            <i class="fas fa-home"></i>
            <span>Beranda</span>
        </a>
        <a href="katalog.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'katalog.php' ? 'active' : ''; ?>">
            <i class="fas fa-book"></i>
            <span>Katalog Buku</span>
        </a>
        <a href="riwayat.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'riwayat.php' ? 'active' : ''; ?>">
            <i class="fas fa-history"></i>
            <span>Riwayat Peminjaman</span>
        </a>
        <?php endif; ?>
        <a href="profil.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'profil.php' ? 'active' : ''; ?>">
            <i class="fas fa-user"></i>
            <span>Profil Saya</span>
        </a>
        <a href="logout.php" class="menu-item">
            <i class="fas fa-sign-out-alt"></i>
            <span>Keluar</span>
        </a>
    </div>
    <div class="content">
        <div class="section">
            <?php if (isset($success)): ?>
            <div class="alert alert-success">
                <?php echo $success; ?>
            </div>
            <?php endif; ?>
            <?php if (isset($error)): ?>
            <div class="alert alert-error">
                <?php echo $error; ?>
            </div>
            <?php endif; ?>
            <div class="profile-header">
                <div class="profile-avatar">
                    <i class="fas fa-user"></i>
                </div>
                <h2><?php echo htmlspecialchars($user['nama_lengkap']); ?></h2>
                <span class="profile-role role-<?php echo $user['role']; ?>">
                    <?php echo ucfirst($user['role']); ?>
                </span>
            </div>
            <form action="profil.php" method="POST">
                <div class="form-group">
                    <label for="nama_lengkap">Nama Lengkap</label>
                    <input type="text" id="nama_lengkap" name="nama_lengkap" 
                           value="<?php echo htmlspecialchars($user['nama_lengkap']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="nisn">NISN</label>
                    <input type="text" id="nisn" value="<?php echo htmlspecialchars($user['nisn']); ?>" readonly>
                </div>
                <div class="form-group">
                    <label for="alamat">Alamat</label>
                    <input type="text" id="alamat" name="alamat" 
                           value="<?php echo htmlspecialchars($user['alamat']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="no_telp">No. Telepon</label>
                    <input type="text" id="no_telp" name="no_telp" 
                           value="<?php echo htmlspecialchars($user['no_telp']); ?>" required>
                </div>
                <button type="submit" name="update_profil" class="update-button">
                    <i class="fas fa-save"></i> Simpan Perubahan
                </button>
            </form>
        </div>
    </div>

    <script>
        // Mobile menu toggle
        const mobileMenuButton = document.querySelector('.mobile-menu-button');
        const sidebar = document.querySelector('.sidebar');
        
        mobileMenuButton.addEventListener('click', () => {
            sidebar.classList.toggle('active');
        });

        // Close sidebar when clicking outside
        document.addEventListener('click', (e) => {
            if (!sidebar.contains(e.target) && !mobileMenuButton.contains(e.target)) {
                sidebar.classList.remove('active');
            }
        });
    </script>
</body>
</html> 