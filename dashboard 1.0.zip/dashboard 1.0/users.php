<?php
session_start();
require_once 'config.php';
require_once 'check_role.php';

// Cek apakah user sudah login dan memiliki role admin
checkAdmin();

// Proses tambah user
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah_user'])) {
    $nama_lengkap = mysqli_real_escape_string($conn, $_POST['nama_lengkap']);
    $nisn = mysqli_real_escape_string($conn, $_POST['nisn']);
    $role = mysqli_real_escape_string($conn, $_POST['role']);
    $alamat = mysqli_real_escape_string($conn, $_POST['alamat']);
    $no_telp = mysqli_real_escape_string($conn, $_POST['no_telp']);
    
    // Cek apakah NISN sudah ada
    $check_nisn = mysqli_query($conn, "SELECT COUNT(*) as total FROM users WHERE nisn = '$nisn'");
    $nisn_exists = mysqli_fetch_assoc($check_nisn)['total'];
    
    if ($nisn_exists > 0) {
        echo "<script>alert('NISN sudah terdaftar! Silakan gunakan NISN lain.'); window.history.back();</script>";
        exit();
    }
    
    $query = "INSERT INTO users (nama_lengkap, nisn, role, alamat, no_telp) 
              VALUES ('$nama_lengkap', '$nisn', '$role', '$alamat', '$no_telp')";
              
    if (mysqli_query($conn, $query)) {
        header('Location: users.php');
        exit();
    } else {
        echo "<script>alert('Gagal menambahkan pengguna! Silakan coba lagi.'); window.history.back();</script>";
        exit();
    }
}

// Proses hapus user
if (isset($_GET['hapus'])) {
    $id = mysqli_real_escape_string($conn, $_GET['hapus']);
    mysqli_query($conn, "DELETE FROM users WHERE id = $id");
    header('Location: users.php');
    exit();
}

// Mengambil data users
$query_users = "SELECT * FROM users ORDER BY created_at DESC";
$result_users = mysqli_query($conn, $query_users);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Pengguna - Perpustakaan Digital</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f6f9;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #fff;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            height: 70px;
        }
        .header h1 {
            font-size: 24px;
            font-weight: 500;
            margin: 0;
        }
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 16px;
        }
        .user-info i {
            font-size: 24px;
        }
        .sidebar {
            background-color: #fff;
            width: 250px;
            height: calc(100vh - 70px);
            position: fixed;
            left: 0;
            top: 70px;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px 0;
            transition: all 0.3s ease;
            z-index: 999;
        }
        .menu-item {
            padding: 15px 25px;
            display: flex;
            align-items: center;
            gap: 15px;
            color: #555;
            text-decoration: none;
            transition: all 0.3s ease;
            font-size: 15px;
            border-left: 4px solid transparent;
        }
        .menu-item:hover {
            background-color: #f8f9fa;
            color: #667eea;
        }
        .menu-item.active {
            background-color: #f0f2ff;
            color: #667eea;
            border-left: 4px solid #667eea;
        }
        .menu-item i {
            width: 20px;
            text-align: center;
            font-size: 18px;
        }
        .content {
            margin-left: 250px;
            padding: 90px 30px 30px;
            transition: all 0.3s ease;
            min-height: 100vh;
        }
        .section {
            background: #fff;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            margin-bottom: 30px;
        }
        .section h3 {
            color: #333;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        th {
            color: #666;
            font-weight: 500;
        }
        .tambah-button {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 12px 25px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-size: 16px;
            margin-bottom: 20px;
            transition: all 0.3s ease;
        }
        .tambah-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        .action-button {
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s ease;
        }
        .edit-button {
            background-color: #ffc107;
            color: white;
        }
        .hapus-button {
            background-color: #dc3545;
            color: white;
        }
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 1001;
        }
        .modal-content {
            background-color: #fff;
            padding: 30px;
            border-radius: 15px;
            width: 90%;
            max-width: 500px;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #555;
        }
        .form-group input, .form-group select {
            width: 100%;
            padding: 10px;
            border: 2px solid #e1e1e1;
            border-radius: 5px;
            font-size: 14px;
        }
        .close-button {
            position: absolute;
            top: 15px;
            right: 15px;
            font-size: 24px;
            cursor: pointer;
            color: #666;
        }
        .role-badge {
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 12px;
            font-weight: 500;
        }
        .role-admin {
            background-color: #e3f2fd;
            color: #1976d2;
        }
        .role-guru {
            background-color: #f3e5f5;
            color: #7b1fa2;
        }
        .role-siswa {
            background-color: #e8f5e9;
            color: #388e3c;
        }
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            .sidebar.active {
                transform: translateX(0);
            }
            .content {
                margin-left: 0;
            }
            table {
                display: block;
                overflow-x: auto;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <div style="display: flex; align-items: center; gap: 15px;">
            <i class="fas fa-bars mobile-menu-button"></i>
            <h1>LIBDIG YOSAGI</h1>
        </div>
        <div class="user-info">
            <i class="fas fa-user-circle"></i>
            <span><?php echo htmlspecialchars($_SESSION['nama_lengkap']); ?></span>
        </div>
    </div>
    <div class="sidebar">
        <a href="index.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">
            <i class="fas fa-home"></i>
            <span>Beranda</span>
        </a>
        <a href="buku.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'buku.php' ? 'active' : ''; ?>">
            <i class="fas fa-book"></i>
            <span>Manajemen Buku</span>
        </a>
        <a href="buku_digital.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'buku_digital.php' ? 'active' : ''; ?>">
            <i class="fas fa-tablet-alt"></i>
            <span>Buku Digital</span>
        </a>
        <a href="peminjaman.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'peminjaman.php' ? 'active' : ''; ?>">
            <i class="fas fa-exchange-alt"></i>
            <span>Manajemen Peminjaman</span>
        </a>
        <a href="users.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'users.php' ? 'active' : ''; ?>">
            <i class="fas fa-users"></i>
            <span>Manajemen Pengguna</span>
        </a>
        <a href="laporan.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'laporan.php' ? 'active' : ''; ?>">
            <i class="fas fa-chart-bar"></i>
            <span>Laporan</span>
        </a>
        <a href="profil.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'profil.php' ? 'active' : ''; ?>">
            <i class="fas fa-user"></i>
            <span>Profil Saya</span>
        </a>
        <a href="logout.php" class="menu-item">
            <i class="fas fa-sign-out-alt"></i>
            <span>Keluar</span>
        </a>
    </div>
    <div class="content">
        <div class="section">
            <h3>Manajemen Pengguna</h3>
            <button class="tambah-button" onclick="openModal()">
                <i class="fas fa-plus"></i> Tambah Pengguna
            </button>
            <table>
                <thead>
                    <tr>
                        <th>Nama Lengkap</th>
                        <th>NISN</th>
                        <th>Role</th>
                        <th>Alamat</th>
                        <th>No. Telepon</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($user = mysqli_fetch_assoc($result_users)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($user['nama_lengkap']); ?></td>
                        <td><?php echo htmlspecialchars($user['nisn']); ?></td>
                        <td>
                            <span class="role-badge role-<?php echo $user['role']; ?>">
                                <?php echo ucfirst($user['role']); ?>
                            </span>
                        </td>
                        <td><?php echo htmlspecialchars($user['alamat']); ?></td>
                        <td><?php echo htmlspecialchars($user['no_telp']); ?></td>
                        <td>
                            <button class="action-button edit-button" onclick="editUser(<?php echo $user['id']; ?>)">
                                <i class="fas fa-edit"></i> Edit
                            </button>
                            <button class="action-button hapus-button" 
                                    onclick="if(confirm('Apakah Anda yakin ingin menghapus pengguna ini?')) 
                                            window.location.href='users.php?hapus=<?php echo $user['id']; ?>'">
                                <i class="fas fa-trash"></i> Hapus
                            </button>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Modal Tambah Pengguna -->
    <div id="tambahModal" class="modal">
        <div class="modal-content">
            <span class="close-button" onclick="closeModal()">&times;</span>
            <h3 style="margin-bottom: 20px;">Tambah Pengguna</h3>
            <form action="users.php" method="POST">
                <div class="form-group">
                    <label for="nama_lengkap">Nama Lengkap</label>
                    <input type="text" id="nama_lengkap" name="nama_lengkap" required>
                </div>
                <div class="form-group">
                    <label for="nisn">NISN</label>
                    <input type="text" id="nisn" name="nisn" required>
                </div>
                <div class="form-group">
                    <label for="role">Role</label>
                    <select id="role" name="role" required>
                        <option value="">Pilih Role</option>
                        <option value="admin">Admin</option>
                        <option value="guru">Guru</option>
                        <option value="siswa">Siswa</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="alamat">Alamat</label>
                    <input type="text" id="alamat" name="alamat" required>
                </div>
                <div class="form-group">
                    <label for="no_telp">No. Telepon</label>
                    <input type="text" id="no_telp" name="no_telp" required>
                </div>
                <button type="submit" name="tambah_user" class="tambah-button">
                    <i class="fas fa-plus"></i> Tambah Pengguna
                </button>
            </form>
        </div>
    </div>

    <script>
        // Mobile menu toggle
        const mobileMenuButton = document.querySelector('.mobile-menu-button');
        const sidebar = document.querySelector('.sidebar');
        
        mobileMenuButton.addEventListener('click', () => {
            sidebar.classList.toggle('active');
        });

        // Close sidebar when clicking outside
        document.addEventListener('click', (e) => {
            if (!sidebar.contains(e.target) && !mobileMenuButton.contains(e.target)) {
                sidebar.classList.remove('active');
            }
        });

        // Modal functions
        function openModal() {
            document.getElementById('tambahModal').style.display = 'block';
        }

        function closeModal() {
            document.getElementById('tambahModal').style.display = 'none';
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('tambahModal');
            if (event.target == modal) {
                modal.style.display = 'none';
            }
        }

        function editUser(id) {
            // Implementasi fungsi edit user
            alert('Fitur edit pengguna akan segera hadir!');
        }
    </script>
</body>
</html> 