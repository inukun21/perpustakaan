<?php
require_once 'config/auth.php';
require_once 'config/database.php';

// Cek apakah ID buku ada
if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$id = mysqli_real_escape_string($conn, $_GET['id']);

// Ambil data buku digital
$sql = "SELECT * FROM digital_books WHERE id = '$id'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) == 0) {
    header("Location: index.php");
    exit();
}

$book = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="theme-color" content="#0d6efd">
    <title><?php echo $book['judul']; ?> - Perpustakaan Digital</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <style>
        :root {
            --primary-color: #0d6efd;
            --secondary-color: #6c757d;
            --success-color: #198754;
            --info-color: #0dcaf0;
            --warning-color: #ffc107;
            --danger-color: #dc3545;
        }
        body {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            background-color: #f8f9fa;
        }
        .navbar {
            background-color: var(--primary-color) !important;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            height: 56px;
        }
        .book-detail {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            padding: 2rem;
            margin: 2rem auto;
            max-width: 1200px;
        }
        .book-image {
            width: 100%;
            max-width: 250px;
            height: 350px;
            object-fit: cover;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .book-icon {
            width: 100%;
            max-width: 250px;
            height: 350px;
            background-color: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .book-info {
            margin-top: 1rem;
        }
        .book-info p {
            margin-bottom: 0.5rem;
            font-size: 0.95rem;
        }
        .book-info i {
            width: 20px;
            color: var(--primary-color);
            font-size: 1.1rem;
        }
        .book-description {
            margin-top: 2rem;
            padding-top: 2rem;
            border-top: 1px solid #dee2e6;
        }
        .book-description h4 {
            font-size: 1.25rem;
            margin-bottom: 1rem;
        }
        .book-description p {
            font-size: 0.95rem;
            line-height: 1.6;
            color: #4a5568;
        }
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.75rem 1.5rem;
            font-size: 1rem;
        }
        .btn i {
            font-size: 1.1rem;
        }
        .footer {
            background-color: var(--primary-color);
            color: white;
            padding: 2rem 0;
            margin-top: auto;
        }
        .footer h5 {
            font-size: 1.1rem;
            margin-bottom: 1rem;
        }
        .footer p {
            font-size: 0.9rem;
            opacity: 0.9;
        }
        .footer-link {
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            transition: color 0.3s ease;
            font-size: 0.9rem;
        }
        .footer-link:hover {
            color: white;
        }
        .footer ul {
            margin-bottom: 0;
        }
        .footer ul li {
            margin-bottom: 0.5rem;
        }
        .footer ul li i {
            width: 20px;
            font-size: 1rem;
        }
        @media (max-width: 768px) {
            .book-detail {
                padding: 1.5rem;
                margin: 1rem;
            }
            .book-image, .book-icon {
                max-width: 200px;
                height: 280px;
            }
            h1 {
                font-size: 1.75rem;
            }
            .book-info p {
                font-size: 0.9rem;
            }
            .book-description p {
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="bi bi-book"></i> Perpustakaan Digital
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="katalog.php">
                            <i class="bi bi-grid"></i> Katalog
                        </a>
                    </li>
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="profile.php">
                                <i class="bi bi-person"></i> Profil
                            </a>
                        </li>
                        <?php if ($_SESSION['role'] == 'admin'): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="admin/dashboard.php">
                                    <i class="bi bi-speedometer2"></i> Admin Panel
                                </a>
                            </li>
                        <?php endif; ?>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">
                                <i class="bi bi-box-arrow-right"></i> Keluar
                            </a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="login.php">
                                <i class="bi bi-box-arrow-in-right"></i> Masuk
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Book Detail -->
    <div class="container">
        <div class="book-detail">
            <div class="row">
                <div class="col-md-4 text-center">
                    <?php if ($book['gambar']): ?>
                        <img src="uploads/<?php echo $book['gambar']; ?>" alt="<?php echo $book['judul']; ?>" class="book-image">
                    <?php else: ?>
                        <div class="book-icon">
                            <i class="bi bi-file-earmark-text"></i>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-md-8">
                    <h1 class="mb-4"><?php echo $book['judul']; ?></h1>
                    <div class="book-info">
                        <p><i class="bi bi-person"></i> <strong>Penulis:</strong> <?php echo $book['penulis']; ?></p>
                        <p><i class="bi bi-building"></i> <strong>Penerbit:</strong> <?php echo $book['penerbit']; ?></p>
                        <p><i class="bi bi-calendar"></i> <strong>Tahun:</strong> <?php echo $book['tahun']; ?></p>
                        <p><i class="bi bi-tag"></i> <strong>Kategori:</strong> <?php echo $book['kategori']; ?></p>
                    </div>
                    <div class="book-description">
                        <h4>Deskripsi</h4>
                        <p><?php echo nl2br($book['deskripsi']); ?></p>
                    </div>
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <a href="uploads/<?php echo $book['file']; ?>" class="btn btn-primary btn-lg mt-3" target="_blank">
                            <i class="bi bi-download"></i> Download PDF
                        </a>
                    <?php else: ?>
                        <a href="login.php" class="btn btn-primary btn-lg mt-3">
                            <i class="bi bi-box-arrow-in-right"></i> Masuk untuk Download
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4">
                    <h5>Perpustakaan Digital</h5>
                    <p>Menyediakan akses ke ribuan koleksi buku fisik dan digital untuk meningkatkan pengetahuan dan wawasan.</p>
                </div>
                <div class="col-md-4 mb-4">
                    <h5>Link Cepat</h5>
                    <ul class="list-unstyled">
                        <li><a href="#" class="footer-link">Tentang Kami</a></li>
                        <li><a href="#" class="footer-link">Kontak</a></li>
                        <li><a href="#" class="footer-link">FAQ</a></li>
                    </ul>
                </div>
                <div class="col-md-4 mb-4">
                    <h5>Kontak</h5>
                    <ul class="list-unstyled">
                        <li><i class="bi bi-geo-alt"></i> Jl. Contoh No. 123, Kota</li>
                        <li><i class="bi bi-telephone"></i> (021) 1234-5678</li>
                        <li><i class="bi bi-envelope"></i> info@perpustakaandigital.com</li>
                    </ul>
                </div>
            </div>
            <hr class="my-4" style="border-color: rgba(255,255,255,0.1);">
            <div class="text-center">
                <p class="mb-0">&copy; <?php echo date('Y'); ?> Perpustakaan Digital. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 