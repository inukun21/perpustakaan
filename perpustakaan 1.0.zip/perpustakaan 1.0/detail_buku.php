<?php
require_once 'config/auth.php';
require_once 'config/database.php';

// Cek apakah ID buku ada
if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$id = mysqli_real_escape_string($conn, $_GET['id']);

// Ambil data buku
$sql = "SELECT * FROM books WHERE id = '$id'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) == 0) {
    header("Location: index.php");
    exit();
}

$book = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="theme-color" content="#0d6efd">
    <title><?php echo $book['judul']; ?> - Perpustakaan Digital</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <style>
        :root {
            --primary-color: #0d6efd;
            --secondary-color: #6c757d;
            --success-color: #198754;
            --info-color: #0dcaf0;
            --warning-color: #ffc107;
            --danger-color: #dc3545;
        }
        body {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            background-color: #f8f9fa;
        }
        .navbar {
            background-color: var(--primary-color) !important;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .book-detail {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin: 2rem 0;
        }
        .book-image {
            width: 100%;
            height: 400px;
            object-fit: cover;
            border-radius: 10px 0 0 10px;
        }
        .book-icon {
            width: 100%;
            height: 400px;
            background-color: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 5rem;
            border-radius: 10px 0 0 10px;
        }
        .book-info {
            padding: 2rem;
        }
        .book-title {
            font-size: 2rem;
            font-weight: bold;
            margin-bottom: 1rem;
        }
        .book-meta {
            color: var(--secondary-color);
            margin-bottom: 1.5rem;
        }
        .book-meta i {
            width: 24px;
            text-align: center;
        }
        .book-description {
            line-height: 1.6;
            color: #444;
        }
        .book-category {
            display: inline-block;
            padding: 0.5rem 1rem;
            background-color: var(--primary-color);
            color: white;
            border-radius: 20px;
            font-size: 0.875rem;
            margin-bottom: 1rem;
        }
        .footer {
            background-color: var(--primary-color);
            color: white;
            padding: 2rem 0;
            margin-top: 3rem;
        }
        .footer-link {
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            transition: color 0.3s ease;
        }
        .footer-link:hover {
            color: white;
        }
        @media (max-width: 768px) {
            .book-image, .book-icon {
                height: 300px;
                border-radius: 10px 10px 0 0;
            }
            .book-info {
                padding: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="bi bi-book"></i> Perpustakaan Digital
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="profile.php">
                                <i class="bi bi-person"></i> Profil
                            </a>
                        </li>
                        <?php if ($_SESSION['role'] == 'admin'): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="admin/dashboard.php">
                                    <i class="bi bi-speedometer2"></i> Admin Panel
                                </a>
                            </li>
                        <?php endif; ?>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">
                                <i class="bi bi-box-arrow-right"></i> Keluar
                            </a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="login.php">
                                <i class="bi bi-box-arrow-in-right"></i> Masuk
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Book Detail Section -->
    <div class="container">
        <div class="book-detail">
            <div class="row">
                <div class="col-md-4 p-0">
                    <?php if ($book['gambar']): ?>
                        <img src="uploads/<?php echo $book['gambar']; ?>" class="book-image" alt="<?php echo $book['judul']; ?>">
                    <?php else: ?>
                        <div class="book-icon">
                            <i class="bi bi-book"></i>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-md-8">
                    <div class="book-info">
                        <span class="book-category">
                            <i class="bi bi-tag"></i> <?php echo $book['kategori']; ?>
                        </span>
                        <h1 class="book-title"><?php echo $book['judul']; ?></h1>
                        <div class="book-meta">
                            <p class="mb-2">
                                <i class="bi bi-person"></i> Penulis: <?php echo $book['penulis']; ?>
                            </p>
                            <p class="mb-2">
                                <i class="bi bi-building"></i> Penerbit: <?php echo $book['penerbit']; ?>
                            </p>
                            <p class="mb-2">
                                <i class="bi bi-calendar"></i> Tahun Terbit: <?php echo $book['tahun']; ?>
                            </p>
                            <p class="mb-2">
                                <i class="bi bi-box"></i> Stok: 
                                <?php if ($book['stok'] > 0): ?>
                                    <span class="badge bg-success"><?php echo $book['stok']; ?> tersedia</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Stok habis</span>
                                <?php endif; ?>
                            </p>
                        </div>
                        <div class="book-description">
                            <?php echo nl2br($book['deskripsi']); ?>
                        </div>
                        <div class="mt-4">
                            <?php if (isset($_SESSION['user_id'])): ?>
                                <?php if ($book['stok'] > 0): ?>
                                    <form action="pinjam.php" method="POST" class="mt-4">
                                        <input type="hidden" name="book_id" value="<?php echo $book['id']; ?>">
                                        <button type="submit" class="btn btn-primary">
                                            <i class="bi bi-book"></i> Pinjam Buku
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <button class="btn btn-secondary mt-4" disabled>
                                        <i class="bi bi-x-circle"></i> Stok Habis
                                    </button>
                                <?php endif; ?>
                            <?php else: ?>
                                <a href="login.php" class="btn btn-primary">
                                    <i class="bi bi-box-arrow-in-right"></i> Masuk untuk Meminjam
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4">
                    <h5>Perpustakaan Digital</h5>
                    <p>Menyediakan akses ke ribuan koleksi buku fisik dan digital untuk meningkatkan pengetahuan dan wawasan.</p>
                </div>
                <div class="col-md-4 mb-4">
                    <h5>Link Cepat</h5>
                    <ul class="list-unstyled">
                        <li><a href="#" class="footer-link">Tentang Kami</a></li>
                        <li><a href="#" class="footer-link">Kontak</a></li>
                        <li><a href="#" class="footer-link">FAQ</a></li>
                    </ul>
                </div>
                <div class="col-md-4 mb-4">
                    <h5>Kontak</h5>
                    <ul class="list-unstyled">
                        <li><i class="bi bi-geo-alt"></i> Jl. Contoh No. 123, Kota</li>
                        <li><i class="bi bi-telephone"></i> (021) 1234-5678</li>
                        <li><i class="bi bi-envelope"></i> info@perpustakaandigital.com</li>
                    </ul>
                </div>
            </div>
            <hr class="my-4" style="border-color: rgba(255,255,255,0.1);">
            <div class="text-center">
                <p class="mb-0">&copy; <?php echo date('Y'); ?> Perpustakaan Digital. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 