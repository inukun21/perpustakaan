<?php
require_once 'config/auth.php';
require_once 'config/database.php';

// Ambil kategori dari URL jika ada
$kategori = isset($_GET['kategori']) ? mysqli_real_escape_string($conn, $_GET['kategori']) : '';

// Query untuk mengambil semua kategori unik
$sql_kategori = "SELECT DISTINCT kategori FROM books ORDER BY kategori";
$result_kategori = mysqli_query($conn, $sql_kategori);

// Query untuk mengambil buku dengan filter kategori
$sql_books = "SELECT * FROM books";
if ($kategori) {
    $sql_books .= " WHERE kategori = '$kategori'";
}
$sql_books .= " ORDER BY id DESC";
$result_books = mysqli_query($conn, $sql_books);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="theme-color" content="#0d6efd">
    <title>Katalog Buku - Perpustakaan Digital</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <style>
        :root {
            --primary-color: #0d6efd;
            --secondary-color: #6c757d;
            --success-color: #198754;
            --info-color: #0dcaf0;
            --warning-color: #ffc107;
            --danger-color: #dc3545;
        }
        body {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            background-color: #f8f9fa;
        }
        .navbar {
            background-color: var(--primary-color) !important;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .book-card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
            height: 100%;
        }
        .book-card:hover {
            transform: translateY(-5px);
        }
        .book-image {
            height: 200px;
            object-fit: cover;
            border-radius: 10px 10px 0 0;
        }
        .book-icon {
            width: 100%;
            height: 200px;
            background-color: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            border-radius: 10px 10px 0 0;
        }
        .category-badge {
            display: inline-block;
            padding: 0.5rem 1rem;
            background-color: var(--primary-color);
            color: white;
            border-radius: 20px;
            text-decoration: none;
            transition: all 0.3s ease;
            margin: 0.25rem;
        }
        .category-badge:hover {
            background-color: #0a58ca;
            color: white;
        }
        .category-badge.active {
            background-color: #0a58ca;
        }
        .footer {
            background-color: var(--primary-color);
            color: white;
            padding: 2rem 0;
            margin-top: 3rem;
        }
        .footer-link {
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            transition: color 0.3s ease;
        }
        .footer-link:hover {
            color: white;
        }
        .section-title {
            position: relative;
            padding-bottom: 1rem;
            margin-bottom: 2rem;
        }
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 50px;
            height: 3px;
            background-color: var(--primary-color);
        }
        .empty-state {
            text-align: center;
            padding: 3rem 0;
        }
        .empty-state i {
            font-size: 4rem;
            color: var(--secondary-color);
            margin-bottom: 1rem;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="bi bi-book"></i> Perpustakaan Digital
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="profile.php">
                                <i class="bi bi-person"></i> Profil
                            </a>
                        </li>
                        <?php if ($_SESSION['role'] == 'admin'): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="admin/dashboard.php">
                                    <i class="bi bi-speedometer2"></i> Admin Panel
                                </a>
                            </li>
                        <?php endif; ?>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">
                                <i class="bi bi-box-arrow-right"></i> Keluar
                            </a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="login.php">
                                <i class="bi bi-box-arrow-in-right"></i> Masuk
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Katalog Section -->
    <div class="container py-4">
        <h2 class="section-title">Katalog Buku</h2>
        
        <!-- Kategori Filter -->
        <div class="mb-4">
            <a href="katalog.php" class="category-badge <?php echo !$kategori ? 'active' : ''; ?>">
                <i class="bi bi-grid"></i> Semua
            </a>
            <?php while ($row = mysqli_fetch_assoc($result_kategori)): ?>
                <a href="katalog.php?kategori=<?php echo urlencode($row['kategori']); ?>" 
                   class="category-badge <?php echo $kategori == $row['kategori'] ? 'active' : ''; ?>">
                    <i class="bi bi-tag"></i> <?php echo $row['kategori']; ?>
                </a>
            <?php endwhile; ?>
        </div>

        <!-- Daftar Buku -->
        <div class="row g-4">
            <?php if (mysqli_num_rows($result_books) > 0): ?>
                <?php while ($book = mysqli_fetch_assoc($result_books)): ?>
                    <div class="col-md-4 col-lg-2">
                        <div class="card book-card">
                            <?php if ($book['gambar']): ?>
                                <img src="uploads/<?php echo $book['gambar']; ?>" class="card-img-top book-image" alt="<?php echo $book['judul']; ?>">
                            <?php else: ?>
                                <div class="book-icon">
                                    <i class="bi bi-book"></i>
                                </div>
                            <?php endif; ?>
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $book['judul']; ?></h5>
                                <p class="card-text text-muted small">
                                    <i class="bi bi-person"></i> <?php echo $book['penulis']; ?><br>
                                    <i class="bi bi-building"></i> <?php echo $book['penerbit']; ?><br>
                                    <i class="bi bi-calendar"></i> <?php echo $book['tahun']; ?>
                                </p>
                                <a href="detail_buku.php?id=<?php echo $book['id']; ?>" class="btn btn-primary btn-sm w-100">
                                    <i class="bi bi-eye"></i> Lihat Detail
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="col-12">
                    <div class="empty-state">
                        <i class="bi bi-book"></i>
                        <h3>Tidak Ada Buku</h3>
                        <p class="text-muted">Tidak ada buku yang tersedia dalam kategori ini.</p>
                        <a href="katalog.php" class="btn btn-primary">
                            <i class="bi bi-arrow-left"></i> Kembali ke Semua Kategori
                        </a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4">
                    <h5>Perpustakaan Digital</h5>
                    <p>Menyediakan akses ke ribuan koleksi buku fisik dan digital untuk meningkatkan pengetahuan dan wawasan.</p>
                </div>
                <div class="col-md-4 mb-4">
                    <h5>Link Cepat</h5>
                    <ul class="list-unstyled">
                        <li><a href="#" class="footer-link">Tentang Kami</a></li>
                        <li><a href="#" class="footer-link">Kontak</a></li>
                        <li><a href="#" class="footer-link">FAQ</a></li>
                    </ul>
                </div>
                <div class="col-md-4 mb-4">
                    <h5>Kontak</h5>
                    <ul class="list-unstyled">
                        <li><i class="bi bi-geo-alt"></i> Jl. Contoh No. 123, Kota</li>
                        <li><i class="bi bi-telephone"></i> (021) 1234-5678</li>
                        <li><i class="bi bi-envelope"></i> info@perpustakaandigital.com</li>
                    </ul>
                </div>
            </div>
            <hr class="my-4" style="border-color: rgba(255,255,255,0.1);">
            <div class="text-center">
                <p class="mb-0">&copy; <?php echo date('Y'); ?> Perpustakaan Digital. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 