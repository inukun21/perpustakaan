<?php
require_once 'config/auth.php';
require_once 'config/database.php';

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Ambil data buku terbaru
$sql_books = "SELECT * FROM books ORDER BY id DESC LIMIT 6";
$result_books = mysqli_query($conn, $sql_books);

// Ambil data buku digital terbaru
$sql_digital = "SELECT * FROM digital_books ORDER BY id DESC LIMIT 6";
$result_digital = mysqli_query($conn, $sql_digital);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="theme-color" content="#0d6efd">
    <title>Perpustakaan Digital</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <style>
        :root {
            --primary-color: #0d6efd;
            --secondary-color: #6c757d;
            --success-color: #198754;
            --info-color: #0dcaf0;
            --warning-color: #ffc107;
            --danger-color: #dc3545;
        }
        body {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            background-color: #f8f9fa;
        }
        .navbar {
            background-color: var(--primary-color) !important;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            backdrop-filter: blur(10px);
            background: rgba(13, 110, 253, 0.95) !important;
        }
        .hero-section {
            background: linear-gradient(135deg, var(--primary-color), #0a58ca);
            color: white;
            padding: 4rem 0;
            margin-bottom: 2rem;
            position: relative;
            overflow: hidden;
        }
        .hero-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="rgba(255,255,255,0.1)" d="M0,96L48,112C96,128,192,160,288,160C384,160,480,128,576,112C672,96,768,96,864,112C960,128,1056,160,1152,160C1248,160,1344,128,1392,112L1440,96L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path></svg>') no-repeat bottom;
            background-size: cover;
            opacity: 0.1;
        }
        .hero-content {
            position: relative;
            z-index: 1;
        }
        .hero-title {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 1rem;
            line-height: 1.2;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
        }
        .hero-subtitle {
            font-size: 1.1rem;
            margin-bottom: 1.5rem;
            opacity: 0.9;
        }
        .feature-card {
            border: none;
            border-radius: 12px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            height: 100%;
            background: white;
            overflow: hidden;
            padding: 1.5rem;
        }
        .feature-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 8px 15px rgba(0,0,0,0.1);
        }
        .feature-icon {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary-color), #0a58ca);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            margin-bottom: 1rem;
            transition: all 0.3s ease;
        }
        .feature-card:hover .feature-icon {
            transform: scale(1.1);
        }
        .card {
            border: none;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            height: 100%;
            display: flex;
            flex-direction: column;
            max-width: 220px;
            margin: 0 auto;
            background: white;
            border-radius: 10px;
            overflow: hidden;
        }
        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 8px 15px rgba(0,0,0,0.1);
        }
        .card-body {
            flex: 1;
            display: flex;
            flex-direction: column;
            padding: 0.75rem;
        }
        .card-title {
            font-size: 0.9rem;
            font-weight: 600;
            margin-bottom: 0.4rem;
            color: #2d3748;
            line-height: 1.2;
            height: 2.2rem;
            overflow: hidden;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
        }
        .card-text {
            font-size: 0.8rem;
            color: #718096;
            margin-bottom: 0.5rem;
            flex: 1;
            overflow: hidden;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
        }
        .book-image {
            width: 100%;
            height: 120px;
            object-fit: cover;
            transition: all 0.3s ease;
        }
        .card:hover .book-image {
            transform: scale(1.05);
        }
        .book-icon {
            width: 100%;
            height: 120px;
            background: linear-gradient(135deg, var(--primary-color), #0a58ca);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            transition: all 0.3s ease;
        }
        .card:hover .book-icon {
            transform: scale(1.05);
        }
        .book-info {
            margin-top: 0.4rem;
            font-size: 0.8rem;
            color: #718096;
        }
        .book-info i {
            width: 14px;
            text-align: center;
            margin-right: 0.3rem;
            color: var(--primary-color);
        }
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
            padding: 0.3rem 0.6rem;
            font-size: 0.8rem;
            transition: all 0.3s ease;
            border-radius: 5px;
            font-weight: 500;
        }
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color), #0a58ca);
            border: none;
        }
        .btn-primary:hover {
            background: linear-gradient(135deg, #0a58ca, var(--primary-color));
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(13, 110, 253, 0.3);
        }
        .section-title {
            position: relative;
            padding-bottom: 0.75rem;
            margin-bottom: 1.5rem;
            font-size: 1.75rem;
            font-weight: 600;
            color: #2d3748;
        }
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 40px;
            height: 3px;
            background: linear-gradient(135deg, var(--primary-color), #0a58ca);
            border-radius: 2px;
        }
        .footer {
            background: linear-gradient(135deg, var(--primary-color), #0a58ca);
            color: white;
            padding: 2rem 0;
            margin-top: 3rem;
        }
        .footer-link {
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            transition: all 0.3s ease;
            display: inline-block;
            margin-bottom: 0.5rem;
        }
        .footer-link:hover {
            color: white;
            transform: translateX(5px);
        }
        .footer-icon {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            background: rgba(255,255,255,0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 0.75rem;
            transition: all 0.3s ease;
            font-size: 0.9rem;
        }
        .footer-icon:hover {
            background: rgba(255,255,255,0.2);
            transform: translateY(-3px);
        }
        @media (max-width: 768px) {
            .hero-title {
                font-size: 2rem;
            }
            .hero-subtitle {
                font-size: 1rem;
            }
            .section-title {
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="#">
                <i class="bi bi-book"></i> Perpustakaan Digital
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="katalog.php">
                            <i class="bi bi-grid"></i> Katalog
                        </a>
                    </li>
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="profile.php">
                                <i class="bi bi-person"></i> Profil
                            </a>
                        </li>
                        <?php if ($_SESSION['role'] == 'admin'): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="admin/dashboard.php">
                                    <i class="bi bi-speedometer2"></i> Admin Panel
                                </a>
                            </li>
                        <?php endif; ?>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">
                                <i class="bi bi-box-arrow-right"></i> Keluar
                            </a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="login.php">
                                <i class="bi bi-box-arrow-in-right"></i> Masuk
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6 hero-content">
                    <h1 class="hero-title">Selamat Datang di Perpustakaan Digital</h1>
                    <p class="hero-subtitle">Akses ribuan koleksi buku fisik dan digital secara mudah dan cepat. Tingkatkan pengetahuan Anda dengan membaca.</p>
                    <?php if (!isset($_SESSION['user_id'])): ?>
                        <a href="register.php" class="btn btn-light btn-lg">
                            <i class="bi bi-person-plus"></i> Daftar Sekarang
                        </a>
                    <?php endif; ?>
                </div>
                <div class="col-md-6 text-center">
                    <img src="https://media.istockphoto.com/id/949118068/id/foto/buku.jpg?s=612x612&w=0&k=20&c=jhmC1_0Gryrq4PBp-SnHLhXPsthZR-2-043MeKQV6RA=" alt="Hero Illustration" class="img-fluid" style="max-width: 400px;">
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="container mb-5">
        <h2 class="text-center mb-4">Fitur Utama</h2>
        <div class="row g-4">
            <div class="col-md-4">
                <div class="card feature-card p-4">
                    <div class="text-center">
                        <div class="feature-icon mx-auto">
                            <i class="bi bi-book"></i>
                        </div>
                        <h3>Koleksi Lengkap</h3>
                        <p class="text-muted">Akses ribuan koleksi buku fisik dan digital dari berbagai kategori.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card feature-card p-4">
                    <div class="text-center">
                        <div class="feature-icon mx-auto">
                            <i class="bi bi-file-earmark-text"></i>
                        </div>
                        <h3>Buku Digital</h3>
                        <p class="text-muted">Baca buku digital kapan saja dan di mana saja dengan mudah.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card feature-card p-4">
                    <div class="text-center">
                        <div class="feature-icon mx-auto">
                            <i class="bi bi-clock"></i>
                        </div>
                        <h3>Akses 24/7</h3>
                        <p class="text-muted">Akses perpustakaan digital kapan saja, 24 jam sehari, 7 hari seminggu.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Latest Books Section -->
    <section class="container mb-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="section-title mb-0">Buku Terbaru</h2>
            <a href="katalog.php" class="btn btn-primary">
                <i class="bi bi-grid"></i> Lihat Semua
            </a>
        </div>
        <div class="row g-4">
            <?php while ($book = mysqli_fetch_assoc($result_books)): ?>
                <div class="col-md-4 col-lg-3 mb-4">
                    <div class="card">
                        <?php if ($book['gambar']): ?>
                            <img src="uploads/<?php echo htmlspecialchars($book['gambar']); ?>" class="book-image" alt="<?php echo htmlspecialchars($book['judul']); ?>">
                        <?php else: ?>
                            <div class="book-icon">
                                <i class="bi bi-book"></i>
                            </div>
                        <?php endif; ?>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo htmlspecialchars($book['judul']); ?></h5>
                            <p class="card-text"><?php echo htmlspecialchars($book['deskripsi']); ?></p>
                            <div class="book-info">
                                <p><i class="bi bi-person"></i> <?php echo htmlspecialchars($book['penulis']); ?></p>
                                <p><i class="bi bi-building"></i> <?php echo htmlspecialchars($book['penerbit']); ?></p>
                                <p><i class="bi bi-calendar"></i> <?php echo htmlspecialchars($book['tahun']); ?></p>
                                <p><i class="bi bi-tag"></i> <?php echo htmlspecialchars($book['kategori']); ?></p>
                                <p><i class="bi bi-box"></i> Stok: <?php echo $book['stok']; ?></p>
                            </div>
                            <div class="mt-auto">
                                <a href="detail_buku.php?id=<?php echo $book['id']; ?>" class="btn btn-primary w-100">
                                    <i class="bi bi-eye"></i> Lihat Detail
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    </section>

    <!-- Latest Digital Books Section -->
    <section class="container mb-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="section-title mb-0">Buku Digital Terbaru</h2>
            <a href="katalog.php" class="btn btn-primary">
                <i class="bi bi-grid"></i> Lihat Semua
            </a>
        </div>
        <div class="row g-4">
            <?php while ($digital = mysqli_fetch_assoc($result_digital)): ?>
                <div class="col-md-4 col-lg-3 mb-4">
                    <div class="card">
                        <?php if ($digital['gambar']): ?>
                            <img src="uploads/<?php echo htmlspecialchars($digital['gambar']); ?>" class="book-image" alt="<?php echo htmlspecialchars($digital['judul']); ?>">
                        <?php else: ?>
                            <div class="book-icon">
                                <i class="bi bi-file-earmark-text"></i>
                            </div>
                        <?php endif; ?>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo htmlspecialchars($digital['judul']); ?></h5>
                            <p class="card-text"><?php echo htmlspecialchars($digital['deskripsi']); ?></p>
                            <div class="book-info">
                                <p><i class="bi bi-person"></i> <?php echo htmlspecialchars($digital['penulis']); ?></p>
                                <p><i class="bi bi-building"></i> <?php echo htmlspecialchars($digital['penerbit']); ?></p>
                                <p><i class="bi bi-calendar"></i> <?php echo htmlspecialchars($digital['tahun']); ?></p>
                                <p><i class="bi bi-tag"></i> <?php echo htmlspecialchars($digital['kategori']); ?></p>
                            </div>
                            <div class="mt-auto">
                                <a href="detail_digital.php?id=<?php echo $digital['id']; ?>" class="btn btn-primary w-100">
                                    <i class="bi bi-eye"></i> Lihat Detail
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4">
                    <h5 class="mb-4">Perpustakaan Digital</h5>
                    <p class="mb-4">Menyediakan akses ke ribuan koleksi buku fisik dan digital untuk meningkatkan pengetahuan dan wawasan.</p>
                    <div class="d-flex">
                        <a href="#" class="footer-icon">
                            <i class="bi bi-facebook"></i>
                        </a>
                        <a href="#" class="footer-icon">
                            <i class="bi bi-twitter"></i>
                        </a>
                        <a href="#" class="footer-icon">
                            <i class="bi bi-instagram"></i>
                        </a>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <h5 class="mb-4">Link Cepat</h5>
                    <ul class="list-unstyled">
                        <li><a href="#" class="footer-link"><i class="bi bi-chevron-right"></i> Tentang Kami</a></li>
                        <li><a href="#" class="footer-link"><i class="bi bi-chevron-right"></i> Kontak</a></li>
                        <li><a href="#" class="footer-link"><i class="bi bi-chevron-right"></i> FAQ</a></li>
                    </ul>
                </div>
                <div class="col-md-4 mb-4">
                    <h5 class="mb-4">Kontak</h5>
                    <ul class="list-unstyled">
                        <li class="mb-3">
                            <i class="bi bi-geo-alt"></i> Jl. Contoh No. 123, Kota
                        </li>
                        <li class="mb-3">
                            <i class="bi bi-telephone"></i> (021) 1234-5678
                        </li>
                        <li class="mb-3">
                            <i class="bi bi-envelope"></i> info@perpustakaandigital.com
                        </li>
                    </ul>
                </div>
            </div>
            <hr class="my-4" style="border-color: rgba(255,255,255,0.1);">
            <div class="text-center">
                <p class="mb-0">&copy; <?php echo date('Y'); ?> Perpustakaan Digital. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 