<?php

// Ambil data kategori
$sql_categories = "SELECT * FROM categories ORDER BY nama_kategori";
$result_categories = mysqli_query($conn, $sql_categories);

// Proses form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $judul = mysqli_real_escape_string($conn, $_POST['judul']);
    $penulis = mysqli_real_escape_string($conn, $_POST['penulis']);
    $penerbit = mysqli_real_escape_string($conn, $_POST['penerbit']);
    $tahun = mysqli_real_escape_string($conn, $_POST['tahun']);
    $deskripsi = mysqli_real_escape_string($conn, $_POST['deskripsi']);
    $stok = mysqli_real_escape_string($conn, $_POST['stok']);
    $kategori_ids = isset($_POST['kategori']) ? $_POST['kategori'] : [];

    // Upload gambar
    $gambar = '';
    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] == 0) {
        $target_dir = "../uploads/books/";
        $file_extension = strtolower(pathinfo($_FILES["gambar"]["name"], PATHINFO_EXTENSION));
        $gambar = uniqid() . '.' . $file_extension;
        $target_file = $target_dir . $gambar;
        
        if (move_uploaded_file($_FILES["gambar"]["tmp_name"], $target_file)) {
            // Gambar berhasil diupload
        }
    }

    // Insert ke tabel books
    $sql = "INSERT INTO books (judul, penulis, penerbit, tahun, deskripsi, stok, gambar) 
            VALUES ('$judul', '$penulis', '$penerbit', '$tahun', '$deskripsi', '$stok', '$gambar')";
    
    if (mysqli_query($conn, $sql)) {
        $book_id = mysqli_insert_id($conn);
        
        // Insert kategori
        foreach ($kategori_ids as $category_id) {
            $category_id = mysqli_real_escape_string($conn, $category_id);
            $sql_category = "INSERT INTO book_categories (book_id, category_id) VALUES ('$book_id', '$category_id')";
            mysqli_query($conn, $sql_category);
        }
        
        header("Location: books.php");
        exit();
    }
}

<!-- Form HTML -->
<div class="card">
    <div class="card-body">
        <h5 class="card-title">Tambah Buku Baru</h5>
        <form method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="judul" class="form-label">Judul Buku</label>
                <input type="text" class="form-control" id="judul" name="judul" required>
            </div>
            <div class="mb-3">
                <label for="penulis" class="form-label">Penulis</label>
                <input type="text" class="form-control" id="penulis" name="penulis" required>
            </div>
            <div class="mb-3">
                <label for="penerbit" class="form-label">Penerbit</label>
                <input type="text" class="form-control" id="penerbit" name="penerbit" required>
            </div>
            <div class="mb-3">
                <label for="tahun" class="form-label">Tahun Terbit</label>
                <input type="number" class="form-control" id="tahun" name="tahun" required>
            </div>
            <div class="mb-3">
                <label for="kategori" class="form-label">Kategori</label>
                <select class="form-select" id="kategori" name="kategori[]" multiple required>
                    <?php while ($category = mysqli_fetch_assoc($result_categories)): ?>
                        <option value="<?php echo $category['id']; ?>">
                            <?php echo htmlspecialchars($category['nama_kategori']); ?>
                        </option>
                    <?php endwhile; ?>
                </select>
                <small class="text-muted">Tekan Ctrl (Windows) atau Command (Mac) untuk memilih beberapa kategori</small>
            </div>
            <div class="mb-3">
                <label for="deskripsi" class="form-label">Deskripsi</label>
                <textarea class="form-control" id="deskripsi" name="deskripsi" rows="3" required></textarea>
            </div>
            <div class="mb-3">
                <label for="stok" class="form-label">Stok</label>
                <input type="number" class="form-control" id="stok" name="stok" required>
            </div>
            <div class="mb-3">
                <label for="gambar" class="form-label">Gambar Buku</label>
                <input type="file" class="form-control" id="gambar" name="gambar" accept="image/*">
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
    </div>
</div> 