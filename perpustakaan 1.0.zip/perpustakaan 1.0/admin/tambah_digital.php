<?php
require_once '../config/auth.php';
require_once '../config/database.php';

checkLogin();
checkAdmin();

// Proses tambah buku digital
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $judul = mysqli_real_escape_string($conn, $_POST['judul']);
    $penulis = mysqli_real_escape_string($conn, $_POST['penulis']);
    $penerbit = mysqli_real_escape_string($conn, $_POST['penerbit']);
    $tahun = mysqli_real_escape_string($conn, $_POST['tahun']);
    $kategori = mysqli_real_escape_string($conn, $_POST['kategori']);
    $deskripsi = mysqli_real_escape_string($conn, $_POST['deskripsi']);
    
    // Upload gambar
    $gambar = '';
    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] == 0) {
        $target_dir = "../uploads/";
        $file_extension = strtolower(pathinfo($_FILES["gambar"]["name"], PATHINFO_EXTENSION));
        $new_filename = uniqid() . '.' . $file_extension;
        $target_file = $target_dir . $new_filename;
        
        if (move_uploaded_file($_FILES["gambar"]["tmp_name"], $target_file)) {
            $gambar = $new_filename;
        }
    }

    // Upload file PDF
    $file_pdf = '';
    if (isset($_FILES['file_pdf']) && $_FILES['file_pdf']['error'] == 0) {
        $target_dir = "../uploads/";
        $file_extension = strtolower(pathinfo($_FILES["file_pdf"]["name"], PATHINFO_EXTENSION));
        if ($file_extension == 'pdf') {
            $new_filename = uniqid() . '.pdf';
            $target_file = $target_dir . $new_filename;
            
            if (move_uploaded_file($_FILES["file_pdf"]["tmp_name"], $target_file)) {
                $file_pdf = $new_filename;
            }
        } else {
            $error = "File harus berformat PDF!";
        }
    }

    if (!isset($error)) {
        $sql = "INSERT INTO digital_books (judul, penulis, penerbit, tahun, kategori, deskripsi, gambar, file) 
                VALUES ('$judul', '$penulis', '$penerbit', '$tahun', '$kategori', '$deskripsi', '$gambar', '$file_pdf')";
        
        if (mysqli_query($conn, $sql)) {
            header("Location: digital.php");
            exit();
        } else {
            $error = "Error: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="theme-color" content="#0d6efd">
    <title>Tambah Buku Digital - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <style>
        :root {
            --primary-color: #0d6efd;
            --secondary-color: #6c757d;
            --success-color: #198754;
            --info-color: #0dcaf0;
            --warning-color: #ffc107;
            --danger-color: #dc3545;
        }
        body {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            background-color: #f8f9fa;
        }
        .navbar {
            background-color: var(--primary-color) !important;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            height: 56px;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1030;
        }
        .sidebar {
            background-color: white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            height: calc(100vh - 56px);
            position: fixed;
            top: 56px;
            left: 0;
            width: 16.666667%; /* col-md-2 */
            overflow-y: auto;
            z-index: 1020;
        }
        .main-content {
            margin-left: 16.666667%; /* col-md-2 */
            margin-top: 56px;
            padding: 1.5rem;
            min-height: calc(100vh - 56px);
        }
        .list-group-item {
            border: none;
            padding: 1rem;
            color: var(--secondary-color);
        }
        .list-group-item:hover {
            background-color: #f8f9fa;
            color: var(--primary-color);
        }
        .list-group-item.active {
            background-color: var(--primary-color);
            color: white;
        }
        .list-group-item i {
            width: 24px;
            text-align: center;
        }
        .card {
            border: none;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 1.5rem;
        }
        .card-header {
            background-color: white;
            border-bottom: 1px solid rgba(0,0,0,.125);
            padding: 1rem;
        }
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }
        .book-icon {
            width: 80px;
            height: 80px;
            border-radius: 8px;
            background-color: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            margin: 0 auto 1rem;
        }
        .preview-image {
            max-width: 200px;
            max-height: 300px;
            object-fit: cover;
            border-radius: 8px;
            margin-top: 1rem;
        }
        .file-info {
            font-size: 0.875rem;
            color: var(--secondary-color);
            margin-top: 0.25rem;
        }
        @media (max-width: 768px) {
            .sidebar {
                position: static;
                width: 100%;
                height: auto;
                margin-bottom: 1rem;
            }
            .main-content {
                margin-left: 0;
                margin-top: 56px;
            }
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <i class="bi bi-book"></i> Perpustakaan Digital
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../index.php">
                            <i class="bi bi-house"></i> Beranda
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">
                            <i class="bi bi-box-arrow-right"></i> Keluar
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 px-0">
                <div class="sidebar p-3">
                    <div class="list-group">
                        <a href="dashboard.php" class="list-group-item list-group-item-action">
                            <i class="bi bi-speedometer2"></i> Dashboard
                        </a>
                        <a href="buku.php" class="list-group-item list-group-item-action">
                            <i class="bi bi-book"></i> Kelola Buku
                        </a>
                        <a href="digital.php" class="list-group-item list-group-item-action active">
                            <i class="bi bi-file-earmark-text"></i> Buku Digital
                        </a>
                        <a href="users.php" class="list-group-item list-group-item-action">
                            <i class="bi bi-people"></i> Kelola Pengguna
                        </a>
                    </div>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 main-content">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Tambah Buku Digital</h2>
                    <a href="digital.php" class="btn btn-secondary">
                        <i class="bi bi-arrow-left"></i> Kembali
                    </a>
                </div>

                <div class="card">
                    <div class="card-body">
                        <?php if (isset($error)): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <?php echo $error; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>

                        <div class="text-center mb-4">
                            <div class="book-icon">
                                <i class="bi bi-file-earmark-text"></i>
                            </div>
                            <h4>Form Tambah Buku Digital</h4>
                            <p class="text-muted">Silakan isi data buku digital baru</p>
                        </div>

                        <form method="POST" enctype="multipart/form-data" class="needs-validation" novalidate>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="judul" class="form-label">Judul Buku</label>
                                        <input type="text" class="form-control" id="judul" name="judul" required>
                                        <div class="invalid-feedback">
                                            Judul buku harus diisi
                                        </div>
                                    </div>

                                    <div class="mb-3">
                                        <label for="penulis" class="form-label">Penulis</label>
                                        <input type="text" class="form-control" id="penulis" name="penulis" required>
                                        <div class="invalid-feedback">
                                            Nama penulis harus diisi
                                        </div>
                                    </div>

                                    <div class="mb-3">
                                        <label for="penerbit" class="form-label">Penerbit</label>
                                        <input type="text" class="form-control" id="penerbit" name="penerbit" required>
                                        <div class="invalid-feedback">
                                            Nama penerbit harus diisi
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="tahun" class="form-label">Tahun Terbit</label>
                                        <input type="number" class="form-control" id="tahun" name="tahun" required>
                                        <div class="invalid-feedback">
                                            Tahun terbit harus diisi
                                        </div>
                                    </div>

                                    <div class="mb-3">
                                        <label for="kategori" class="form-label">Kategori</label>
                                        <select class="form-select" id="kategori" name="kategori" required>
                                            <option value="">Pilih Kategori</option>
                                            <option value="Novel">Novel</option>
                                            <option value="Pendidikan">Pendidikan</option>
                                            <option value="Sejarah">Sejarah</option>
                                            <option value="Biografi">Biografi</option>
                                            <option value="Sains">Sains</option>
                                            <option value="Lainnya">Lainnya</option>
                                        </select>
                                        <div class="invalid-feedback">
                                            Kategori harus dipilih
                                        </div>
                                    </div>

                                    <div class="mb-3">
                                        <label for="gambar" class="form-label">Gambar Buku</label>
                                        <input type="file" class="form-control" id="gambar" name="gambar" accept="image/*">
                                        <div id="imagePreview" class="text-center"></div>
                                    </div>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label for="deskripsi" class="form-label">Deskripsi</label>
                                <textarea class="form-control" id="deskripsi" name="deskripsi" rows="4" required></textarea>
                                <div class="invalid-feedback">
                                    Deskripsi harus diisi
                                </div>
                            </div>

                            <div class="mb-3">
                                <label for="file_pdf" class="form-label">File PDF</label>
                                <input type="file" class="form-control" id="file_pdf" name="file_pdf" accept=".pdf" required>
                                <div class="file-info">
                                    <i class="bi bi-info-circle"></i> Format file harus PDF
                                </div>
                                <div class="invalid-feedback">
                                    File PDF harus diupload
                                </div>
                            </div>

                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-plus"></i> Tambah Buku Digital
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Form validation
        (function () {
            'use strict'
            var forms = document.querySelectorAll('.needs-validation')
            Array.prototype.slice.call(forms).forEach(function (form) {
                form.addEventListener('submit', function (event) {
                    if (!form.checkValidity()) {
                        event.preventDefault()
                        event.stopPropagation()
                    }
                    form.classList.add('was-validated')
                }, false)
            })
        })()

        // Image preview
        document.getElementById('gambar').addEventListener('change', function(e) {
            const preview = document.getElementById('imagePreview');
            preview.innerHTML = '';
            
            if (this.files && this.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const img = document.createElement('img');
                    img.src = e.target.result;
                    img.className = 'preview-image';
                    preview.appendChild(img);
                }
                reader.readAsDataURL(this.files[0]);
            }
        });
    </script>
</body>
</html> 