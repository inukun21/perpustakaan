<?php
require_once '../config/auth.php';
require_once '../config/database.php';

checkLogin();
checkAdmin();

// Cek apakah ID buku ada
if (!isset($_GET['id'])) {
    header("Location: buku.php");
    exit();
}

$id = mysqli_real_escape_string($conn, $_GET['id']);

// Ambil data buku
$sql = "SELECT * FROM books WHERE id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "s", $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) == 0) {
    header("Location: buku.php");
    exit();
}

$book = mysqli_fetch_assoc($result);

// Proses update buku
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $judul = mysqli_real_escape_string($conn, $_POST['judul']);
    $penulis = mysqli_real_escape_string($conn, $_POST['penulis']);
    $penerbit = mysqli_real_escape_string($conn, $_POST['penerbit']);
    $tahun = mysqli_real_escape_string($conn, $_POST['tahun']);
    $kategori = mysqli_real_escape_string($conn, $_POST['kategori']);
    $deskripsi = mysqli_real_escape_string($conn, $_POST['deskripsi']);
    $stok = mysqli_real_escape_string($conn, $_POST['stok']);
    
    // Upload gambar baru
    $gambar = $book['gambar'];
    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] == 0) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        $file_type = $_FILES['gambar']['type'];
        
        if (!in_array($file_type, $allowed_types)) {
            $error = "Format gambar tidak valid. Gunakan JPG, PNG, atau GIF.";
        } else {
            $target_dir = "../uploads/";
            $file_extension = strtolower(pathinfo($_FILES["gambar"]["name"], PATHINFO_EXTENSION));
            $new_filename = uniqid() . '.' . $file_extension;
            $target_file = $target_dir . $new_filename;
            
            if (move_uploaded_file($_FILES["gambar"]["tmp_name"], $target_file)) {
                // Hapus gambar lama jika ada
                if ($book['gambar'] && file_exists("../uploads/" . $book['gambar'])) {
                    unlink("../uploads/" . $book['gambar']);
                }
                $gambar = $new_filename;
            } else {
                $error = "Gagal mengupload gambar.";
            }
        }
    }

    if (!isset($error)) {
        $sql = "UPDATE books SET 
                judul = ?,
                penulis = ?,
                penerbit = ?,
                tahun = ?,
                kategori = ?,
                deskripsi = ?,
                stok = ?,
                gambar = ?
                WHERE id = ?";
                
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "sssssssss", $judul, $penulis, $penerbit, $tahun, $kategori, $deskripsi, $stok, $gambar, $id);
        
        if (mysqli_stmt_execute($stmt)) {
            header("Location: buku.php");
            exit();
        } else {
            $error = "Error: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="theme-color" content="#0d6efd">
    <title>Edit Buku - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <style>
        :root {
            --primary-color: #0d6efd;
            --secondary-color: #6c757d;
            --success-color: #198754;
            --info-color: #0dcaf0;
            --warning-color: #ffc107;
            --danger-color: #dc3545;
        }
        body {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            background-color: #f8f9fa;
        }
        .navbar {
            background-color: var(--primary-color) !important;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            height: 56px;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1030;
        }
        .sidebar {
            background-color: white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            height: calc(100vh - 56px);
            position: fixed;
            top: 56px;
            left: 0;
            width: 16.666667%; /* col-md-2 */
            overflow-y: auto;
            z-index: 1020;
        }
        .list-group-item {
            border: none;
            padding: 0.75rem 1rem;
            color: var(--secondary-color);
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }
        .list-group-item:hover {
            background-color: #f8f9fa;
            color: var(--primary-color);
            transform: translateX(5px);
        }
        .list-group-item.active {
            background-color: var(--primary-color);
            color: white;
        }
        .list-group-item i {
            width: 20px;
            text-align: center;
            font-size: 1.1rem;
        }
        .card {
            border: none;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 1.5rem;
            border-radius: 10px;
            transition: all 0.3s ease;
        }
        .card:hover {
            box-shadow: 0 4px 8px rgba(0,0,0,0.15);
        }
        .card-header {
            background-color: white;
            border-bottom: 1px solid rgba(0,0,0,.125);
            padding: 1.25rem;
            border-radius: 10px 10px 0 0;
        }
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.75rem 1.5rem;
            font-size: 0.95rem;
            transition: all 0.3s ease;
        }
        .btn:hover {
            transform: translateY(-2px);
        }
        .btn-sm {
            padding: 0.5rem 1rem;
            font-size: 0.875rem;
        }
        .btn-lg {
            padding: 0.75rem 1.5rem;
            font-size: 1rem;
        }
        .preview-image {
            max-width: 180px;
            max-height: 250px;
            object-fit: cover;
            border-radius: 6px;
            margin-top: 0.5rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
        }
        .preview-image:hover {
            transform: scale(1.05);
        }
        .form-label {
            font-size: 0.95rem;
            font-weight: 500;
            margin-bottom: 0.5rem;
            color: #2d3748;
        }
        .form-control {
            font-size: 0.95rem;
            padding: 0.75rem 1rem;
            border: 1px solid #e2e8f0;
            border-radius: 6px;
            transition: all 0.3s ease;
        }
        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(13, 110, 253, 0.15);
        }
        .form-select {
            font-size: 0.95rem;
            padding: 0.75rem 1rem;
            border: 1px solid #e2e8f0;
            border-radius: 6px;
            transition: all 0.3s ease;
        }
        .form-select:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(13, 110, 253, 0.15);
        }
        .alert {
            font-size: 0.95rem;
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
        }
        h2 {
            font-size: 1.75rem;
            margin-bottom: 0;
            color: #2d3748;
        }
        h4 {
            font-size: 1.25rem;
            margin-bottom: 0.75rem;
            color: #2d3748;
        }
        .text-muted {
            font-size: 0.95rem;
            color: #718096 !important;
        }
        .mb-3 {
            margin-bottom: 1.25rem !important;
        }
        .mb-4 {
            margin-bottom: 1.5rem !important;
        }
        .main-content {
            margin-left: 16.666667%; /* col-md-2 */
            margin-top: 56px;
            padding: 1.5rem;
            min-height: calc(100vh - 56px);
        }
        @media (max-width: 768px) {
            .sidebar {
                position: static;
                width: 100%;
                height: auto;
                margin-bottom: 1rem;
            }
            .main-content {
                margin-left: 0;
                margin-top: 56px;
            }
            .preview-image {
                max-width: 150px;
                max-height: 200px;
            }
            h2 {
                font-size: 1.5rem;
            }
            .form-control, .form-select {
                padding: 0.5rem 0.75rem;
            }
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <i class="bi bi-book"></i> Perpustakaan Digital
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../index.php">
                            <i class="bi bi-house"></i> Beranda
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">
                            <i class="bi bi-box-arrow-right"></i> Keluar
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 px-0">
                <div class="sidebar p-3">
                    <div class="list-group">
                        <a href="dashboard.php" class="list-group-item list-group-item-action">
                            <i class="bi bi-speedometer2"></i> Dashboard
                        </a>
                        <a href="buku.php" class="list-group-item list-group-item-action active">
                            <i class="bi bi-book"></i> Kelola Buku
                        </a>
                        <a href="digital.php" class="list-group-item list-group-item-action">
                            <i class="bi bi-file-earmark-text"></i> Buku Digital
                        </a>
                        <a href="users.php" class="list-group-item list-group-item-action">
                            <i class="bi bi-people"></i> Kelola Pengguna
                        </a>
                    </div>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 main-content">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Edit Buku</h2>
                    <a href="buku.php" class="btn btn-secondary">
                        <i class="bi bi-arrow-left"></i> Kembali
                    </a>
                </div>

                <div class="card">
                    <div class="card-body">
                        <?php if (isset($error)): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <?php echo $error; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>

                        <div class="mb-4">
                            <h4>Form Edit Buku</h4>
                            <p class="text-muted">Silakan edit data buku</p>
                        </div>

                        <form method="POST" enctype="multipart/form-data" class="needs-validation" novalidate>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="judul" class="form-label">Judul Buku</label>
                                        <input type="text" class="form-control" id="judul" name="judul" value="<?php echo htmlspecialchars($book['judul']); ?>" required>
                                        <div class="invalid-feedback">
                                            Judul buku harus diisi
                                        </div>
                                    </div>

                                    <div class="mb-3">
                                        <label for="penulis" class="form-label">Penulis</label>
                                        <input type="text" class="form-control" id="penulis" name="penulis" value="<?php echo htmlspecialchars($book['penulis']); ?>" required>
                                        <div class="invalid-feedback">
                                            Nama penulis harus diisi
                                        </div>
                                    </div>

                                    <div class="mb-3">
                                        <label for="penerbit" class="form-label">Penerbit</label>
                                        <input type="text" class="form-control" id="penerbit" name="penerbit" value="<?php echo htmlspecialchars($book['penerbit']); ?>" required>
                                        <div class="invalid-feedback">
                                            Nama penerbit harus diisi
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="tahun" class="form-label">Tahun Terbit</label>
                                        <input type="number" class="form-control" id="tahun" name="tahun" value="<?php echo htmlspecialchars($book['tahun']); ?>" min="1900" max="<?php echo date('Y'); ?>" required>
                                        <div class="invalid-feedback">
                                            Tahun terbit harus diisi dengan benar
                                        </div>
                                    </div>

                                    <div class="mb-3">
                                        <label for="kategori" class="form-label">Kategori</label>
                                        <select class="form-select" id="kategori" name="kategori" required>
                                            <option value="">Pilih Kategori</option>
                                            <?php
                                            $categories = ['Novel', 'Pendidikan', 'Sejarah', 'Biografi', 'Sains', 'Lainnya'];
                                            foreach ($categories as $category) {
                                                $selected = ($book['kategori'] == $category) ? 'selected' : '';
                                                echo "<option value=\"" . htmlspecialchars($category) . "\" $selected>" . htmlspecialchars($category) . "</option>";
                                            }
                                            ?>
                                        </select>
                                        <div class="invalid-feedback">
                                            Kategori harus dipilih
                                        </div>
                                    </div>

                                    <div class="mb-3">
                                        <label for="stok" class="form-label">Stok</label>
                                        <input type="number" class="form-control" id="stok" name="stok" value="<?php echo htmlspecialchars($book['stok']); ?>" min="0" required>
                                        <div class="invalid-feedback">
                                            Stok harus diisi dengan benar
                                        </div>
                                    </div>

                                    <div class="mb-3">
                                        <label for="gambar" class="form-label">Gambar Buku</label>
                                        <?php if ($book['gambar']): ?>
                                            <div class="mb-2">
                                                <img src="../uploads/<?php echo htmlspecialchars($book['gambar']); ?>" alt="Current Image" class="preview-image">
                                            </div>
                                        <?php endif; ?>
                                        <input type="file" class="form-control" id="gambar" name="gambar" accept="image/*">
                                        <div id="imagePreview" class="text-center"></div>
                                        <div class="form-text">Format yang didukung: JPG, PNG, GIF</div>
                                    </div>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label for="deskripsi" class="form-label">Deskripsi</label>
                                <textarea class="form-control" id="deskripsi" name="deskripsi" rows="4" required><?php echo htmlspecialchars($book['deskripsi']); ?></textarea>
                                <div class="invalid-feedback">
                                    Deskripsi harus diisi
                                </div>
                            </div>

                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-save"></i> Simpan Perubahan
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Form validation
        (function () {
            'use strict'
            var forms = document.querySelectorAll('.needs-validation')
            Array.prototype.slice.call(forms).forEach(function (form) {
                form.addEventListener('submit', function (event) {
                    if (!form.checkValidity()) {
                        event.preventDefault()
                        event.stopPropagation()
                    }
                    form.classList.add('was-validated')
                }, false)
            })
        })()

        // Image preview
        document.getElementById('gambar').addEventListener('change', function(e) {
            const preview = document.getElementById('imagePreview');
            preview.innerHTML = '';
            
            if (this.files && this.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const img = document.createElement('img');
                    img.src = e.target.result;
                    img.className = 'preview-image';
                    preview.appendChild(img);
                }
                reader.readAsDataURL(this.files[0]);
            }
        });
    </script>
</body>
</html> 