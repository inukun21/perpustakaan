<?php
require_once '../config/auth.php';
require_once '../config/database.php';

checkLogin();
checkAdmin();

// Ambil ID user dari parameter URL
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Ambil data user
$sql = "SELECT * FROM users WHERE id = $id";
$result = mysqli_query($conn, $sql);
$user = mysqli_fetch_assoc($result);

// Jika user tidak ditemukan, redirect ke halaman users
if (!$user) {
    header("Location: users.php");
    exit();
}

// Proses hapus user
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Jangan izinkan menghapus diri sendiri
    if ($id == $_SESSION['user_id']) {
        $error = "Anda tidak dapat menghapus akun Anda sendiri!";
    } else {
        $sql = "DELETE FROM users WHERE id = $id";
        if (mysqli_query($conn, $sql)) {
            header("Location: users.php");
            exit();
        } else {
            $error = "Error: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="theme-color" content="#0d6efd">
    <title>Hapus Pengguna - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <style>
        :root {
            --primary-color: #0d6efd;
            --secondary-color: #6c757d;
            --success-color: #198754;
            --info-color: #0dcaf0;
            --warning-color: #ffc107;
            --danger-color: #dc3545;
        }
        body {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            background-color: #f8f9fa;
        }
        .navbar {
            background-color: var(--primary-color) !important;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .sidebar {
            background-color: white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            height: calc(100vh - 56px);
            position: sticky;
            top: 56px;
        }
        .list-group-item {
            border: none;
            padding: 1rem;
            color: var(--secondary-color);
        }
        .list-group-item:hover {
            background-color: #f8f9fa;
            color: var(--primary-color);
        }
        .list-group-item.active {
            background-color: var(--primary-color);
            color: white;
        }
        .list-group-item i {
            width: 24px;
            text-align: center;
        }
        .card {
            border: none;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 1.5rem;
        }
        .card-header {
            background-color: white;
            border-bottom: 1px solid rgba(0,0,0,.125);
            padding: 1rem;
        }
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }
        .user-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background-color: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            font-weight: bold;
            margin: 0 auto 1rem;
        }
        .warning-icon {
            font-size: 3rem;
            color: var(--warning-color);
            margin-bottom: 1rem;
        }
        @media (max-width: 768px) {
            .sidebar {
                height: auto;
                position: static;
            }
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <i class="bi bi-book"></i> Perpustakaan Digital
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../index.php">
                            <i class="bi bi-house"></i> Beranda
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">
                            <i class="bi bi-box-arrow-right"></i> Keluar
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 px-0">
                <div class="sidebar p-3">
                    <div class="list-group">
                        <a href="dashboard.php" class="list-group-item list-group-item-action">
                            <i class="bi bi-speedometer2"></i> Dashboard
                        </a>
                        <a href="buku.php" class="list-group-item list-group-item-action">
                            <i class="bi bi-book"></i> Kelola Buku
                        </a>
                        <a href="digital.php" class="list-group-item list-group-item-action">
                            <i class="bi bi-file-earmark-text"></i> Buku Digital
                        </a>
                        <a href="users.php" class="list-group-item list-group-item-action active">
                            <i class="bi bi-people"></i> Kelola Pengguna
                        </a>
                    </div>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Hapus Pengguna</h2>
                    <a href="users.php" class="btn btn-secondary">
                        <i class="bi bi-arrow-left"></i> Kembali
                    </a>
                </div>

                <div class="card">
                    <div class="card-body">
                        <?php if (isset($error)): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <?php echo $error; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>

                        <div class="text-center mb-4">
                            <i class="bi bi-exclamation-triangle warning-icon"></i>
                            <h4>Konfirmasi Penghapusan</h4>
                            <p class="text-muted">Anda akan menghapus pengguna berikut:</p>
                            
                            <div class="user-avatar">
                                <?php echo strtoupper(substr($user['nama_lengkap'], 0, 1)); ?>
                            </div>
                            <h4><?php echo $user['nama_lengkap']; ?></h4>
                            <p class="text-muted">NIS: <?php echo $user['nis']; ?></p>
                            <span class="badge bg-<?php echo $user['role'] === 'admin' ? 'danger' : ($user['role'] === 'guru' ? 'warning' : 'info'); ?>">
                                <?php echo ucfirst($user['role']); ?>
                            </span>
                        </div>

                        <div class="alert alert-warning">
                            <i class="bi bi-exclamation-circle"></i>
                            <strong>Peringatan!</strong> Tindakan ini tidak dapat dibatalkan. Semua data pengguna akan dihapus secara permanen.
                        </div>

                        <form method="POST" class="needs-validation" novalidate>
                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-danger">
                                    <i class="bi bi-trash"></i> Hapus Pengguna
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Form validation
        (function () {
            'use strict'
            var forms = document.querySelectorAll('.needs-validation')
            Array.prototype.slice.call(forms).forEach(function (form) {
                form.addEventListener('submit', function (event) {
                    if (!form.checkValidity()) {
                        event.preventDefault()
                        event.stopPropagation()
                    }
                    form.classList.add('was-validated')
                }, false)
            })
        })()
    </script>
</body>
</html> 