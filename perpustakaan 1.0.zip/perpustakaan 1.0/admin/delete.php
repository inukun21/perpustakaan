<?php
require_once '../config/auth.php';
require_once '../config/database.php';

checkLogin();
checkAdmin();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$type = isset($_GET['type']) ? $_GET['type'] : '';

if ($type === 'buku') {
    // Ambil informasi gambar sebelum menghapus
    $sql = "SELECT gambar FROM books WHERE id = $id";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    
    if ($row) {
        // Hapus file gambar jika ada
        if ($row['gambar']) {
            $file_path = "../uploads/" . $row['gambar'];
            if (file_exists($file_path)) {
                unlink($file_path);
            }
        }
        
        // Hapus data dari database
        $sql = "DELETE FROM books WHERE id = $id";
        mysqli_query($conn, $sql);
    }
} elseif ($type === 'digital') {
    // Ambil informasi file sebelum menghapus
    $sql = "SELECT file FROM digital_books WHERE id = $id";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    
    if ($row) {
        // Hapus file digital jika ada
        if ($row['file']) {
            $file_path = "../uploads/digital/" . $row['file'];
            if (file_exists($file_path)) {
                unlink($file_path);
            }
        }
        
        // Hapus data dari database
        $sql = "DELETE FROM digital_books WHERE id = $id";
        mysqli_query($conn, $sql);
    }
}

// Redirect kembali ke halaman yang sesuai
header("Location: " . ($type === 'buku' ? 'buku.php' : 'digital.php'));
exit(); 